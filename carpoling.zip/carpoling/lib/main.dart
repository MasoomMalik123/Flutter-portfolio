import 'package:carpoling_1/bindings/bindings.dart';
import 'package:carpoling_1/splashScreen/splash_screen.dart';
import 'package:carpoling_1/themeProvider/theme_Provider.dart';
import 'package:carpoling_1/utils/dummy_data.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'Screens/auth/Login_screen.dart';
import 'firebase_options.dart';
import 'infoHandler/app_info.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await checkIfLocationPermissionAllowed();
  // createMultipleGeoDocumentsForCarTows(listOfCarTowsUsers);
  // createMultipleGeoDocumentsForCarMechanics(listOfCarMechanicUsers);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
        title: 'Carpooling',
        themeMode: ThemeMode.system,
        theme: MyThemes.lightTheme, //For default theme
        darkTheme: MyThemes.darkTheme, //For dark theme
        debugShowCheckedModeBanner: false,
        initialBinding: InitialBindings(),
        home: const SplashScreen());
  }
}

checkIfLocationPermissionAllowed() async {
  var locationPermission = await Geolocator.checkPermission();
  if (locationPermission == LocationPermission.denied) {
    locationPermission = await Geolocator.requestPermission();
  }
}
