
import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xffF9F9F9);
const kSecondaryColor = Color(0xffFF453A);
const kTertiaryColor = Color(0xff2C2C2C);
Color kQuaternaryColor = Color(0xff2C2C2C).withOpacity(0.5);

const kBlackColor = Color(0xff000000);
const kWhiteColor = Color(0xffFFFFFF);

// const kGreyColor = Color(0xff7B7B7B);

Color kHintColor = Color(0xff2C2C2C).withOpacity(0.5);
Color kInputBorderColor = Color(0xff2C2C2C).withOpacity(0.1);

const kYellowColor = Color(0xffFFA41B);

const kBlueColor = Color(0xff2B99FF);
const kGreenColor = Color(0xff0E8E1A);
const kOrangeColor = Color(0xffFF6813);
