import 'package:carpoling_1/model/user_model.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/direction_details.dart';
final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
User? currentUser;

UserModel? userModelCurrentInfo;

DirectionDetailsInfo? tripDirectionDetailsInfo;

String userDropOfAddress = "";
