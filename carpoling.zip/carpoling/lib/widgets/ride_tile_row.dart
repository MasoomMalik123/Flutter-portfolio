import 'package:carpoling_1/Screens/driver_panel/driver_rides.dart';
import 'package:flutter/material.dart';

class RideTileRow extends StatelessWidget {
  final String text1;
  final double width;
  final String text2;

  const RideTileRow({
    super.key,
    required this.text1,
    required this.text2,
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          text1,
          style: text1Style,
        ),
        SizedBox(
          width: width,
        ),
        Expanded(
          child: Text(
            // textAlign: TextAlign.center,
            text2,
            style: text2Style,
            // softWrap: true,
          ),
        ),
      ],
    );
    // RichText(
    //     text: TextSpan(
    //   children: [
    //     TextSpan(text: text1, style: text1Style),
    //     TextSpan(
    //       text: text2,
    //       style: text2Style,
    //     ),
    //   ],
    // ));
  }
}
