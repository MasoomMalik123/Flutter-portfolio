import 'package:carpoling_1/utils/utils.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class DashboardCard extends StatelessWidget {
  final List<Color> gradientColorList;
  final String text;
  final VoidCallback onTap;
  const DashboardCard({
    super.key,
    required this.onTap,
    required this.gradientColorList,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(top: 25),
        height: MediaQuery.of(context).size.height * .23,
        width: MediaQuery.of(context).size.height * .33,
        decoration: BoxDecoration(
          color: Colors.deepPurple,
          borderRadius: BorderRadius.circular(8),
          gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: gradientColorList),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: textStyle1,
            ),
          ),
        ),
      ),
    );
  }
}
