import 'package:flutter/material.dart';

AppBar myAppBar(String text) {
  return AppBar(
    title: Text(
      text,
      style: const TextStyle(color: Colors.white),
    ),
    iconTheme: const IconThemeData(color: Colors.white),
    centerTitle: true,
    backgroundColor: Colors.blue,
  );
}
