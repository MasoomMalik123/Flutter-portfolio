import 'package:flutter/material.dart';

class RowProfileCard extends StatelessWidget {
  final String keyVal;
  final String nameVal;
  const RowProfileCard({
    super.key,
    required this.keyVal,
    required this.nameVal,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 10),
        padding: const EdgeInsets.symmetric(horizontal: 6),
        decoration: const BoxDecoration(
          // shape: BoxShape.circle,
          borderRadius: BorderRadius.all(Radius.circular(20)),
          border: Border(
            bottom: BorderSide(color: Colors.black),
            top: BorderSide(color: Colors.black),
            left: BorderSide(color: Colors.black),
            right: BorderSide(color: Colors.black),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Text(
                keyVal,
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.w500),
              ),
            ),
            Padding(
              padding:  EdgeInsets.symmetric(vertical: 15),
              child: Text(nameVal,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w500)),
            ),
          ],
        ),
      ),
    );
  }
}
