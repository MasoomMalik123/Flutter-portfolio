import 'package:flutter/material.dart';

class DashboardButton extends StatelessWidget {
  final String text;
  final Widget widget;
  final Function()? onTap;

  const DashboardButton({
    super.key,
    required this.text,
    required this.widget,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        // margin: const EdgeInsets.all(16),
        height: 50,
        width: 150,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8), color: Colors.yellow),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Icon(MdiIcons.tools),
            widget,
            const SizedBox(
              width: 5,
            ),
            Text(
              text,
              style: const TextStyle(fontWeight: FontWeight.w700),
            )
          ],
        ),
      ),
    );
  }
}
// Image.asset(
//               'images/pngegg.png',
//               scale: 4.5,
//             ),
//             const DashboardButton(
//               text: 'CARPOOLING',
//               widget: FaIcon(FontAwesomeIcons.car),
//             ),
//             const SizedBox(
//               height: 35,
//             ),
//             Image.asset(
//               'images/car_mech_i2.png',
//               scale: 4.5,
//             ),
//             const SizedBox(
//               height: 15,
//             ),
//             DashboardButton(
//               text: 'MECHANICS',
//               widget: Icon(MdiIcons.tools),
//             ),
//             const SizedBox(
//               height: 20,
//             ),
//             Image.asset(
//               'images/cartow.png',
//               scale: 3.5,
//             ),
//             const DashboardButton(
//               text: 'TOWING',
//               widget: FaIcon(FontAwesomeIcons.truckPickup),
//             ),
            // text: 'Find Ride',
            //   onTap: () {
            //     Get.to(() => const UserMainScreen(), binding: UserBindings());
            //   },

            //   text: 'Find Car Tow',
            //   onTap: () {
            //     Get.to(() => const UserCarTowMainScreen(),
            //         binding: CustomerCarTowBindings());
            //   },

              // text: 'Find Car Mechanic',
            //   onTap: () {
            //     Get.to(() => const UserCarMechMainScreen(),
            //         binding: CustomerCarMechanicBindings());
            //   },