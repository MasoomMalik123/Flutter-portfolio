import 'package:flutter/material.dart';

class MyTextField extends StatelessWidget {
  final bool isDarkTheme;
  final Widget? suffixIcon;
  final String hintText;
  final Function(String)? onChanged;
  final TextEditingController? controller;
  final bool isShowprefixIcon;
  final VoidCallback? onTap;
  final TextInputType? textInputType;
  final String? Function(String?)? validator;
  final bool readOnly;
  final int? maxlines;
  const MyTextField({
    super.key,
    required this.hintText,
    this.controller,
    this.maxlines=1,
    this.isDarkTheme = false,
    this.isShowprefixIcon = false,
    this.readOnly =false,
    this.suffixIcon,
    this.onChanged,
    this.onTap,
    this.textInputType,
    this.validator,

  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: TextFormField(
        maxLines: maxlines,
        controller: controller,
        onTap: onTap,
        keyboardType: textInputType,
        validator: validator,
        readOnly: readOnly,
        decoration: InputDecoration(
          hintText: hintText,
          labelText: hintText,
          floatingLabelBehavior: FloatingLabelBehavior.always,
          floatingLabelStyle: const TextStyle(color: Colors.blue),
          hintStyle: const TextStyle(
            color: Colors.grey,
          ),
          // filled: true,
          // fillColor: isDarkTheme ? Colors.black45 : Colors.grey.shade200,
          // border: OutlineInputBorder(
          //   borderRadius: BorderRadius.circular(40),
          //   borderSide: const BorderSide(
          //     width: 5,
          //     style: BorderStyle.none,
          //     color: Colors.blue,
          //   ),
          // ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: const BorderSide(
              width: 2,
              // style: BorderStyle.none,
              color: Colors.blue,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: const BorderSide(
              width: 2,
              // style: BorderStyle.none,
              color: Colors.blue,
            ),
          ),

          prefixIcon: isShowprefixIcon
              ? Icon(
                  Icons.person,
                  color: isDarkTheme ? Colors.amber.shade400 : Colors.grey,
                )
              : const SizedBox.shrink(),
          suffixIcon: suffixIcon,
        ),
        onChanged: onChanged,
        // autovalidateMode: AutovalidateMode.onUserInteraction,
        // validator: (text) {
        //   if (text == null || text.isEmpty) {
        //     return 'Password can not be empty';
        //   }
        //   if (text.length < 2) {
        //     return "Please enter a valid Password";
        //   }
        //   if (text.length > 50) {
        //     return "Password can not be more then 50 ";
        //   }
        //   return null;
        // },
        // onChanged: (text) => setState(() {
        //   passwordTextEditingController.text = text;
        // }),
      ),
    );
  }
}
