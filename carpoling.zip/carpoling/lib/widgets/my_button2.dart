import 'package:carpoling_1/Global/colors.dart';
import 'package:carpoling_1/widgets/mytext.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class MyButton2 extends StatelessWidget {
  MyButton2({
    super.key,
    required this.buttonText,
    required this.onTap,
    this.bgColor = Colors.blue,
    this.textColor = Colors.white,
    this.weight = FontWeight.w500,
    this.height = 48,
    this.textSize = 16,
    this.radius = 8,
    this.isDisable = false,
    this.customChild,
  });

  final String buttonText;
  final VoidCallback onTap;
  double? height, textSize, radius;
  FontWeight? weight;
  bool? haveShadow;
  bool? isDisable;
  Widget? customChild;
  Color? bgColor, textColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: isDisable! ? kSecondaryColor : bgColor,
        borderRadius: BorderRadius.circular(radius!),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isDisable! ? null : onTap,
          splashColor: kBlackColor.withOpacity(0.1),
          highlightColor: kBlackColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(radius!),
          child: customChild ??
              Center(
                child: MyText(
                  text: buttonText,
                  size: textSize,
                  weight: weight,
                  color: isDisable!
                      ? kQuaternaryColor
                      : textColor ?? kPrimaryColor,
                  paddingLeft: 10,
                  paddingRight: 10,
                ),
              ),
        ),
      ),
    );
  }
}

// ignore: must_be_immutable
class MyBorderButton extends StatelessWidget {
  MyBorderButton({
    super.key,
    required this.buttonText,
    required this.onTap,
    this.borderColor = kTertiaryColor,
    this.textColor = kPrimaryColor,
    this.bgColor = Colors.transparent,
    this.weight = FontWeight.w500,
    this.height = 48,
    this.radius = 8,
    this.textSize = 16,
    this.child,
  });

  final String buttonText;
  final VoidCallback onTap;
  double? height, textSize, radius;
  FontWeight? weight;
  Widget? child;
  Color? borderColor, textColor, bgColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius!),
        color: bgColor,
        border: Border.all(
          width: 1.0,
          color: borderColor!,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          splashColor: kSecondaryColor.withOpacity(0.1),
          highlightColor: kSecondaryColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(radius!),
          child: child ??
              Center(
                child: MyText(
                  text: buttonText,
                  size: textSize,
                  weight: weight,
                  color: textColor,
                ),
              ),
        ),
      ),
    );
  }
}
