import 'package:flutter/material.dart';

class MyButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  final Color? buttonColor;
  const MyButton({
    super.key,
    required this.onTap,
    required this.text,
    this.buttonColor = Colors.blue,
  });

  @override
  Widget build(BuildContext context) {
    bool darktheme =
        MediaQuery.of(context).platformBrightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              foregroundColor: darktheme ? Colors.black : Colors.white,
              backgroundColor: darktheme ? Colors.amber.shade400 : buttonColor,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(32),
              ),
              minimumSize: const Size(double.infinity, 50)),
          onPressed: onTap,
          child: Text(
            text,
            style: const TextStyle(
              fontSize: 20,
            ),
          )),
    );
  }
}
