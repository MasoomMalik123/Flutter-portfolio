// import 'package:flutter/cupertino.dart';

// import '../models/directions.dart';


// class Appinfo extends ChangeNotifier{
//   Directions? userPickUpLocation, userDropOffLocation;
//   int countTotalTrips = 0;
//  // List<String> historyTripsKeysList = [];
//  // List<TripsHistoryModel> allTripsHistoryInformationList = [];


// void updatePickUpLoactionAddress(Directions userPickUpAddress){
//   userPickUpLocation = userPickUpAddress;
//   notifyListeners();
// }
// void updateDropOffLocationAddress(Directions dropOffAddress){
//   userDropOffLocation = dropOffAddress;
//   notifyListeners();
// }


// }