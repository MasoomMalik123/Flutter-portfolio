import 'package:carpoling_1/Assistance/request_assistant.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../Global/global.dart';
import '../Global/map_key.dart';
import '../infoHandler/app_info.dart';
import '../models/direction_details.dart';
import '../models/directions.dart';

class AssistantMethods {
  static void readCurrentOnlineUserInfo() async {
    currentUser = firebaseAuth.currentUser;
    // DatabaseReference userRef = FirebaseDatabase.instance
    //  .ref()
    // .child("users")
    // .child(currentUser!.uid);

    // userRef.once().then((snap){
    //   if(snap.snapshot.value != null){
    //     userModelCurrentInfo = UserModel.fromSnapshot(snap.snapshot);
    //   }
    // });
  }
  // static Future <String> searchAddressForGeographicCoOrdinates(Position position, context ) async{

  //    String apiUrl = "https://maps.googleapis.com/maps/api/geocode/json?latLng= ${position.latitude}, ${position.longitude}&key= $mapKey"; //$ before mapkey
  //    String humanReadableAddress = "";
  //    var requestResponse = await RequestAssistant.recieveRequest(apiUrl);
  //    if(requestResponse != "Error Occured.Failed.No Response."){
  //      humanReadableAddress = requestResponse["results"][0]["formatted_address"];

  //      Directions userPickupAddress = Directions();
  //      userPickupAddress.locationLatitude = position.latitude;
  //      userPickupAddress.locationLongitude = position.longitude;
  //      userPickupAddress.locationName = humanReadableAddress;

  //     Provider.of<Appinfo>(context, listen: false).updatePickUpLoactionAddress(userPickupAddress);

  //    }
  //    return humanReadableAddress;
  // }

  static Future<DirectionDetailsInfo> obtainOriginToDestinationDirectionDetails(
      LatLng originPosition, LatLng destinationPosition) async {
    String urlOriginToDestinationDirectionDetails =
        "https://maps.googleapis.com/maps/api/directions/json?origins=${originPosition.latitude},${originPosition.longitude}&destination= ${destinationPosition.latitude},${destinationPosition.longitude}&key=$mapKey";
    var responseDirectionApi = await RequestAssistant.recieveRequest(
        urlOriginToDestinationDirectionDetails);

    // if(responseDirectionApi == "Error Occures. Failed.No Response."){
    //   return null;
    // }

    DirectionDetailsInfo directionDetailsInfo = DirectionDetailsInfo();
    directionDetailsInfo.e_points =
        responseDirectionApi["routes"][0]["overview_polyline"]["points"];

    directionDetailsInfo.distance_text =
        responseDirectionApi["routes"][0]["legs"][0]["distance"]["text"];
    directionDetailsInfo.distance_value =
        responseDirectionApi["routes"][0]["legs"][0]["distance"]["value"];

    directionDetailsInfo.duration_text =
        responseDirectionApi["routes"][0]["legs"][0]["duration"]["text"];
    directionDetailsInfo.duration_value =
        responseDirectionApi["routes"][0]["legs"][0]["duration"]["value"];

    return directionDetailsInfo;
  }
}
