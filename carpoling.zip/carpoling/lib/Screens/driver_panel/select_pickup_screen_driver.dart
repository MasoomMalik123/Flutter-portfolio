import 'dart:convert';

import 'package:carpoling_1/Global/map_key.dart';
import 'package:carpoling_1/Screens/driver_panel/driver_main_screen.dart';
import 'package:carpoling_1/bindings/bindings.dart';
import 'package:carpoling_1/controller/driver_controller.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/my_textfield.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class DriverSelectPickUpScreen extends StatefulWidget {
  const DriverSelectPickUpScreen({super.key});

  @override
  State<DriverSelectPickUpScreen> createState() =>
      _DriverSelectPickUpScreenState();
}

class _DriverSelectPickUpScreenState extends State<DriverSelectPickUpScreen> {
  final TextEditingController _fromSearchController = TextEditingController();
  final TextEditingController _toSearchController = TextEditingController();
  final TextEditingController _carNameController = TextEditingController();
  final TextEditingController _availableSeatController =
      TextEditingController();
  final TextEditingController _perSeatPriceController = TextEditingController();

  List<Map<String, dynamic>> _fromSuggestions = [];
  List<Map<String, dynamic>> _toSuggestions = [];

  double rideStartLat = 0;
  double rideStartLng = 0;
  double rideEndLat = 0;
  double rideEndLng = 0;

  void _getFromPlaceSuggestions(String input) async {
    final apiUrl =
        'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$input&key=$mapKey';

    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final predictions = data['predictions'];

      setState(() {
        _fromSuggestions =
            predictions.map<Map<String, dynamic>>((dynamic prediction) {
          return {
            'description': prediction['description'] as String,
            'placeId': prediction['place_id'] as String,
            'lat': 0.0, // Initialize with a default value
            'lng': 0.0, // Initialize with a default value
          };
        }).toList();
      });
    }
  }

  void _getToPlaceSuggestions(String input) async {
    final apiUrl =
        'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$input&key=$mapKey';

    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final predictions = data['predictions'];

      setState(() {
        _toSuggestions =
            predictions.map<Map<String, dynamic>>((dynamic prediction) {
          return {
            'description': prediction['description'] as String,
            'placeId': prediction['place_id'] as String,
            'lat': 0.0, // Initialize with a default value
            'lng': 0.0, // Initialize with a default value
          };
        }).toList();
      });
    }
  }

  Future<void> _getFromPlaceDetails(String placeId, int index) async {
    final apiUrl =
        'https://maps.googleapis.com/maps/api/place/details/json?place_id=$placeId&key=$mapKey';

    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final location = data['result']['geometry']['location'];
      final double lat = location['lat'];
      final double lng = location['lng'];
      print(lat);
      print(lng);
      rideStartLat = lat;
      rideStartLng = lng;

      print("data");
      print(data);
      setState(() {
        // apiController.getDestLocation(lat, lng);
      });
      // apiController.isDestHasPoint.value = true;

      print('Selected place details - Lat: $lat, Lng: $lng');
    }
  }

  Future<void> _getToPlaceDetails(String placeId, int index) async {
    final apiUrl =
        'https://maps.googleapis.com/maps/api/place/details/json?place_id=$placeId&key=$mapKey';

    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final location = data['result']['geometry']['location'];
      final double lat = location['lat'];
      final double lng = location['lng'];
      print(lat);
      print(lng);
      rideEndLat = lat;
      rideEndLng = lng;
      print("data");
      print(data);
      setState(() {
        // apiController.getDestLocation(lat, lng);
      });
      // apiController.isDestHasPoint.value = true;

      print('Selected place details - Lat: $lat, Lng: $lng');
    }
  }

  bool isShowFromLocation = false;
  bool isShowToLocation = false;
  DriverController driverController = Get.find<DriverController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: const Text('Select Pickup'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                const Text(
                  'From:',
                  style: TextStyle(fontSize: 18),
                ),
                const SizedBox(height: 10),

                MyTextField(
                  controller: _fromSearchController,
                  hintText: 'Enter from location',
                  onTap: () {
                    isShowFromLocation = true;
                    isShowToLocation = false;
                    setState(() {});
                  },
                  onChanged: (value) {
                    setState(() {
                      _getFromPlaceSuggestions(value);
                    });
                  },
                ),
                const SizedBox(height: 10),
                const Text(
                  'To:',
                  style: TextStyle(fontSize: 18),
                ),
                const SizedBox(height: 10),

                MyTextField(
                  controller: _toSearchController,
                  hintText: 'Enter To location',
                  onTap: () {
                    isShowToLocation = true;
                    setState(() {});
                  },
                  onChanged: (value) {
                    setState(() {
                      _getToPlaceSuggestions(value);
                    });
                  },
                ),

                const SizedBox(height: 20),
                const Spacer(),
                // submit carbooking
                MyButton(
                    onTap: () async {
                      showModalBottomSheet(
                        // isDismissible: true,
                        isScrollControlled: true,
                        // useSafeArea: true,
                        context: context,
                        builder: (BuildContext context) {
                          return Padding(
                            padding: EdgeInsets.only(
                              bottom: MediaQuery.of(context).viewInsets.bottom,
                            ),
                            child: Container(
                              padding: const EdgeInsets.all(20.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  MyTextField(
                                    hintText: 'Car Name',
                                    controller: _carNameController,
                                  ),
                                  const SizedBox(height: 30),
                                  MyTextField(
                                    hintText: 'Available Seats',
                                    controller: _availableSeatController,
                                    textInputType: TextInputType.number,
                                  ),
                                  const SizedBox(height: 30),
                                  MyTextField(
                                    hintText: 'Per Seat Price',
                                    controller: _perSeatPriceController,
                                    textInputType: TextInputType.number,
                                  ),
                                  const SizedBox(height: 30),
                                  Row(
                                    // mainAxisAlignment:
                                    //     MainAxisAlignment.spaceBetween,
                                    children: [
                                      InkWell(
                                        onTap: () =>
                                            driverController.pickDate(context),
                                        child: Container(
                                          padding: const EdgeInsets.all(10),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                              color: Colors.blue),
                                          child: const Center(
                                              child: Text(
                                            'Select Ride Date',
                                            style:
                                                TextStyle(color: Colors.white),
                                          )),
                                        ),
                                      ),
                                      const SizedBox(
                                        width: 22,
                                      ),
                                      Obx(
                                        () => Text(
                                            driverController
                                                        .selectedDate.value !=
                                                    null
                                                ? 'Ride Start Date: ${driverController.selectedDate.value!.toLocal().toString().split(' ')[0]}'
                                                : 'No date selected!',
                                            style: const TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w400)),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 16.0),
                                  Row(
                                    children: [
                                      InkWell(
                                        onTap: () =>
                                            driverController.pickTime(context),
                                        child: Container(
                                          padding: const EdgeInsets.all(10),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                              color: Colors.blue),
                                          child: const Center(
                                              child: Text(
                                            'Select Ride Time',
                                            style:
                                                TextStyle(color: Colors.white),
                                          )),
                                        ),
                                      ),
                                      const SizedBox(
                                        width: 22,
                                      ),
                                      Obx(
                                        () => Text(
                                            driverController
                                                        .selectedTime.value ==
                                                    null
                                                ? 'No time selected!'
                                                : 'Ride Start Time: ${driverController.selectedTime.value!.format(context)}',
                                            style: const TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w400)),
                                      ),
                                    ],
                                  ),
                                  MyButton(
                                    onTap: () async {
                                      // Navigator.pop(context);
                                      final id = DateTime.now()
                                          .millisecondsSinceEpoch
                                          .toString();
                                      await FirebaseFirestore.instance
                                          .collection('rides')
                                          .doc(id)
                                          .set({
                                        'bookedRides': [],
                                        'driverId': FirebaseAuth
                                            .instance.currentUser!.uid,
                                        'docId': id,
                                        'driverCarName':
                                            _carNameController.text,
                                        'driverName':
                                            driverController.driverName.value,
                                        'driverEmail':
                                            driverController.driverEmail.value,
                                        'driverPhone':
                                            driverController.driverPhone.value,
                                        'driverSeatsAvailable':
                                            _availableSeatController.text,
                                        'driverRideStartLocation':
                                            _fromSearchController.text,
                                        'driverRideEndLocation':
                                            _toSearchController.text,
                                        'pricePerSeat':
                                            _perSeatPriceController.text,
                                        'driverBookedSeats': '0',
                                        'driverRevenue': '0',
                                        'rideStartLatLng': {
                                          'latitude': rideStartLat.toString(),
                                          'longitude': rideStartLng.toString(),
                                        },
                                        'rideEndLatLng': {
                                          'latitude': rideEndLat.toString(),
                                          'longitude': rideEndLng.toString(),
                                        },
                                        'rideStartTime': driverController
                                                    .selectedTime.value ==
                                                null
                                            ? ''
                                            : driverController
                                                .selectedTime.value!
                                                .format(context)
                                                .toString(),
                                        'rideStartDate': driverController
                                                    .selectedDate.value !=
                                                null
                                            ? driverController
                                                .selectedDate.value!
                                                .toLocal()
                                                .toString()
                                                .split(' ')[0]
                                            : '',
                                      }).then((value) {
                                        Get.offAll(
                                            () => const DriverMainScreen(),
                                            binding: DriverBindings());
                                      });
                                    },
                                    text: 'Finish',
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                    text: 'Next')
              ],
            ),

            // from suggestions
            Visibility(
              visible: isShowFromLocation,
              child: Positioned(
                top: 100,
                left: 0,
                right: 0,
                child: Container(
                  color: Colors.white,
                  height: Get.height * .25,
                  child: ListView.builder(
                    itemCount: _fromSuggestions.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(
                          _fromSuggestions[index]['description'] as String,
                          style: const TextStyle(color: Colors.black),
                        ),
                        onTap: () {
                          isShowFromLocation = false;
                          setState(() {});
                          _getFromPlaceDetails(
                              _fromSuggestions[index]['placeId'] as String,
                              index);
                          _fromSearchController.text =
                              _fromSuggestions[index]['description'] as String;
                        },
                      );
                    },
                  ),
                ),
              ),
            ),

            // to suggestions
            Visibility(
              visible: isShowToLocation,
              child: Positioned(
                top: 200,
                left: 0,
                right: 0,
                child: SizedBox(
                  height: Get.height * .25,
                  child: ListView.builder(
                    itemCount: _toSuggestions.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(
                          _toSuggestions[index]['description'] as String,
                          style: const TextStyle(color: Colors.black),
                        ),
                        onTap: () {
                          isShowToLocation = false;
                          setState(() {});
                          _getToPlaceDetails(
                              _toSuggestions[index]['placeId'] as String,
                              index);
                          _toSearchController.text =
                              _toSuggestions[index]['description'] as String;
                          // Future.delayed(
                          //   Duration(seconds: 1),
                          // );
                          // print(
                          //     'is dest point getted : ${ctlr.isDestHasPoint.value}');

                          // if (ctlr.isDestHasPoint.value) {
                          //   ctlr.getDirection();
                          // }
                        },
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
