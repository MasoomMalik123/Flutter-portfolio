import 'package:carpoling_1/Screens/driver_panel/driver_ride_detail_screen.dart';
import 'package:carpoling_1/controller/driver_controller.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

const text1Style =
    TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black);
const text2Style =
    TextStyle(fontSize: 16, fontWeight: FontWeight.w400, color: Colors.black);

class DriverOwnRidesScreen extends StatefulWidget {
  const DriverOwnRidesScreen({super.key});

  @override
  State<DriverOwnRidesScreen> createState() => _DriverOwnRidesScreenState();
}

class _DriverOwnRidesScreenState extends State<DriverOwnRidesScreen> {
  DriverController driverController = Get.find<DriverController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView.builder(
          itemCount: driverController.currentUserDriverRides.length,
          itemBuilder: ((context, index) {
            var ride = driverController.currentUserDriverRides[index];
            return Container(
              margin: const EdgeInsets.all(15),
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.black)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  RideTileRow(
                    text1: 'From',
                    text2: ride.driverRideStartLocation,
                    width: 10,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  RideTileRow(
                    text1: 'To',
                    text2: ride.driverRideEndLocation,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  MyButton(
                      onTap: () {
                        Get.to(() => DriverRideDetailScreen(rideModel: ride));
                      },
                      text: 'Check Details'),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}
