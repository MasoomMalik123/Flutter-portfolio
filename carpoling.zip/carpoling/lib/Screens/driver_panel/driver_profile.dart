import 'package:carpoling_1/Screens/driver_panel/driver_edit_profile.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/user_edit_profile.dart';
import 'package:carpoling_1/controller/driver_controller.dart';
import 'package:carpoling_1/controller/user_profile_controller.dart';
import 'package:carpoling_1/model/user_model.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/row_profile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class DriverProfile extends StatefulWidget {
  const DriverProfile({super.key});

  @override
  State<DriverProfile> createState() => _DriverProfileState();
}

class _DriverProfileState extends State<DriverProfile> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  DriverController driverController = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Obx(
                () => RowProfileCard(
                  keyVal: 'Name',
                  nameVal: driverController.driverModel.value.name,
                ),
              ),
              RowProfileCard(
                keyVal: 'Email',
                nameVal: driverController.driverModel.value.email,
              ),
              Obx(
                () => RowProfileCard(
                  keyVal: 'Phone',
                  nameVal: driverController.driverModel.value.phone,
                ),
              ),
              RowProfileCard(
                keyVal: 'Role',
                nameVal: driverController.driverModel.value.role,
              ),
              const SizedBox(
                height: 50,
              ),
              MyButton(
                onTap: () {
                  Get.to(() => const DriverEditProfile());
                },
                text: 'Edit Profile',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
