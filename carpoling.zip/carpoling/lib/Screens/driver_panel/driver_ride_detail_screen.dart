import 'package:carpoling_1/Screens/driver_panel/driver_main_screen.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/user_main_screen.dart';
import 'package:carpoling_1/controller/driver_controller.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/controller/user_profile_controller.dart';
import 'package:carpoling_1/model/ride_model.dart';
import 'package:carpoling_1/utils/utils.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class DriverRideDetailScreen extends StatefulWidget {
  final Ride rideModel;
  final bool isShowBookNowButton;
  const DriverRideDetailScreen({
    super.key,
    required this.rideModel,
    this.isShowBookNowButton = false,
  });

  @override
  State<DriverRideDetailScreen> createState() => _DriverRideDetailScreenState();
}

class _DriverRideDetailScreenState extends State<DriverRideDetailScreen> {
  var totalUsers = [];
  var totalRevenue = '0';
  var totalBookedSeats = '0';
  var totalAvailableSeats = '0';
  var pricePerSeat = '0';

  DriverController driverController = Get.find<DriverController>();
  UserController userController = Get.find<UserController>();
  UserProfileController userProfileController =
      Get.find<UserProfileController>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    totalUsers.addAll(widget.rideModel.bookedRides);
    totalRevenue = widget.rideModel.driverRevenue;
    totalBookedSeats = widget.rideModel.driverBookedSeats;
    totalAvailableSeats = widget.rideModel.driverSeatsAvailable;
    pricePerSeat = widget.rideModel.pricePerSeat;
    print(widget.isShowBookNowButton);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ride Details'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              RideTileRow(
                text1: 'Ride ID',
                text2: widget.rideModel.docId,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Driver Name',
                text2: widget.rideModel.driverName,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Driver Email',
                text2: widget.rideModel.driverEmail,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Driver Car',
                text2: widget.rideModel.driverCarName,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Driver Phone',
                text2: widget.rideModel.driverPhone,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Start Location',
                text2: widget.rideModel.driverRideStartLocation,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'End Location',
                text2: widget.rideModel.driverRideEndLocation,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Avaialable seats',
                text2: widget.rideModel.driverSeatsAvailable,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Seat Price',
                text2: widget.rideModel.pricePerSeat,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Ride Start Date ',
                text2: widget.rideModel.rideStartDate,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Ride Start Time',
                text2: widget.rideModel.rideStartTime,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              totalUsers.contains(FirebaseAuth.instance.currentUser!.uid) ||
                      totalAvailableSeats == '0'
                  ? MyButton(
                      onTap: () {},
                      buttonColor: Colors.grey,
                      text: 'Already Booked')
                  : widget.isShowBookNowButton
                      ? MyButton(
                          onTap: () async {
                            // book the seatuid
                            // cuurent user uid
                            totalUsers.add(
                              FirebaseAuth.instance.currentUser!.uid,
                            );
                            // add revenue
                            var seatPrice = int.parse(pricePerSeat);
                            var currentRevenue = int.parse(totalRevenue);
                            var seatsAvailable = int.parse(totalAvailableSeats);
                            var seatsBooked = int.parse(totalBookedSeats);
                            seatsBooked = totalUsers.length;

                            var totalPriceRevenue = currentRevenue + seatPrice;
                            if (seatsAvailable > 0) {
                              seatsAvailable--;
                            } else {
                              showToast('No Seat Left');
                            }

                            // update the firestore ride
                            await FirebaseFirestore.instance
                                .collection('rides')
                                .doc(widget.rideModel.docId)
                                .update({
                              'driverRevenue': totalPriceRevenue.toString(),
                              'driverSeatsAvailable': seatsAvailable.toString(),
                              'bookedRides': totalUsers,
                              'driverBookedSeats': seatsBooked.toString(),
                            }).then((value) {
                              showToast('Your Ride is Booked');
                              userController.getAllBookedRidesForUser();
                              setState(() {});
                            });
                          },
                          text: 'Book Now')
                      : const SizedBox.shrink(),
              MyButton(
                  onTap: () async {
                    var rideStartLat =
                        double.parse(widget.rideModel.rideStartLatLng.latitude);
                    var rideStartLng = double.parse(
                        widget.rideModel.rideStartLatLng.longitude);
                    var rideEndLat =
                        double.parse(widget.rideModel.rideEndLatLng.latitude);
                    var rideEndLng =
                        double.parse(widget.rideModel.rideEndLatLng.longitude);
                    print('routes');
                    print(rideEndLng);
                    print(rideEndLat);
                    print(rideStartLng);
                    print(rideStartLat);
                    if (userProfileController.userModel.value.role == "User") {
                      userController.allMarkers.clear();
                      userController.allMarkers.add(
                        Marker(
                          markerId: const MarkerId('Initial'),
                          position: LatLng(rideStartLat, rideStartLng),
                          consumeTapEvents: true,
                          // rotation: rotation,
                          icon: BitmapDescriptor.defaultMarker,
                        ),
                      );
                      userController.allMarkers.add(
                        Marker(
                          markerId: const MarkerId('Final'),
                          position: LatLng(rideEndLat, rideEndLng),
                          consumeTapEvents: true,
                          // rotation: rotation,
                          icon: BitmapDescriptor.defaultMarker,
                        ),
                      );

                      await userController
                          .getDirectionData(rideStartLat, rideStartLng,
                              rideEndLat, rideEndLng)
                          .then(
                        (value) {
                          userController.isTapedOnShowRoute.value = true;
                          Get.to(() => const UserMainScreen());

                          if (userController.mapController != null) {
                            print(' in ---  if');

                            // new camera position
                            CameraPosition cameraPosition = CameraPosition(
                                target: LatLng(rideStartLat, rideStartLng),
                                zoom: 13);
                            userController.currentCamPosition = cameraPosition;
                            if (userController.mapController != null) {
                              userController.mapController!.animateCamera(
                                  CameraUpdate.newCameraPosition(
                                      cameraPosition));
                            }
                          } else {
                            print(' in ---  else');
                          }
                        },
                      );
                    } else {
                      driverController.allMarkers.clear();
                      driverController.allMarkers.add(
                        Marker(
                          markerId: const MarkerId('Initial'),
                          position: LatLng(rideStartLat, rideStartLng),
                          consumeTapEvents: true,
                          // rotation: rotation,
                          icon: BitmapDescriptor.defaultMarker,
                        ),
                      );
                      driverController.allMarkers.add(
                        Marker(
                          markerId: const MarkerId('Final'),
                          position: LatLng(rideEndLat, rideEndLng),
                          consumeTapEvents: true,
                          // rotation: rotation,
                          icon: BitmapDescriptor.defaultMarker,
                        ),
                      );

                      await driverController
                          .getDirectionData(rideStartLat, rideStartLng,
                              rideEndLat, rideEndLng)
                          .then(
                        (value) {
                          driverController.isTapedOnShowRoute.value = true;
                          Get.to(() => const DriverMainScreen());

                          if (driverController.mapController != null) {
                            print(' in ---  if');

                            // new camera position
                            CameraPosition cameraPosition = CameraPosition(
                                target: LatLng(rideStartLat, rideStartLng),
                                zoom: 13);
                            driverController.currentCamPosition =
                                cameraPosition;
                            if (driverController.mapController != null) {
                              driverController.mapController!.animateCamera(
                                  CameraUpdate.newCameraPosition(
                                      cameraPosition));
                            }
                          } else {
                            print(' in ---  else');
                          }
                        },
                      );
                    }
                  },
                  text: 'Show Route'),
              widget.isShowBookNowButton
                  ? const SizedBox.shrink()
                  : MyButton(onTap: () {}, text: 'Start Ride'),
            ],
          ),
        ),
      ),
    );
  }
}
