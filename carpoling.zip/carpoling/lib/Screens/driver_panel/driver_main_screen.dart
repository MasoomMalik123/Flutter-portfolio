import 'dart:convert';

import 'package:carpoling_1/Screens/auth/Login_screen.dart';
import 'package:carpoling_1/Screens/driver_panel/driver_profile.dart';
import 'package:carpoling_1/Screens/driver_panel/driver_rides.dart';
import 'package:carpoling_1/Screens/driver_panel/select_pickup_screen_driver.dart';
import 'package:carpoling_1/Screens/user_panel/dashboard/dashboard.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/search_places_screen.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/select_pickup_screen_user.dart';
import 'package:carpoling_1/bindings/bindings.dart';
import 'package:carpoling_1/controller/driver_controller.dart';
import 'package:carpoling_1/controller/user_profile_controller.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/my_textfield.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'dart:async';
import 'package:geolocator/geolocator.dart';
// import 'package:location/location.dart' as loc;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../Assistance/assistant_methods.dart';
import '../../Global/global.dart';
import '../../Global/map_key.dart';
import '../../infoHandler/app_info.dart';
import '../../models/directions.dart';
import '../../widgets/progress_dialog.dart';
import 'package:http/http.dart' as http;

class DriverMainScreen extends StatefulWidget {
  const DriverMainScreen({super.key});

  @override
  State<DriverMainScreen> createState() => _DriverMainScreenState();
}

class _DriverMainScreenState extends State<DriverMainScreen> {
  LatLng? pickLocation;
  // loc.Location location = loc.Location();
  String? _address;

  final Completer<GoogleMapController> _controllerGoogleMap = Completer();
  // GoogleMapController? newGoogleMapController;

  //  = CameraPosition(
  //   target: LatLng(37.42796133580664, -122.085749655962),
  //   zoom: 14.4746,
  // );
  final GlobalKey<ScaffoldState> _scaffoldstate = GlobalKey<ScaffoldState>();

  double searchLocationContainerHeight = 220;
  double waitingResponsefromDriverContainerHeight = 0;
  double assignedDriverInfoContainerHeight = 0;
  Position? userCurrentPosition;
  var geoLocation = Geolocator();
  LocationPermission? _locationPermission;
  double bottomPaddingOfMap = 0;
  List<LatLng> pLineCoordinatedList = [];
  Set<Polyline> polylineSet = {};
  Set<Marker> markersSet = {};
  Set<Circle> circlesSet = {};

  String userName = "";
  String userEmail = "";
  bool openNavigationDrawer = true;
  bool activeNearbyDriverKeysLoaded = false;
  BitmapDescriptor? activeNearbyIcon;

  DriverController driverController = Get.find<DriverController>();
  UserProfileController userProfileController =
      Get.find<UserProfileController>();

  locateUserPosition() async {
    Position cPostion = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    userCurrentPosition = cPostion;
    LatLng latlngPosition =
        LatLng(userCurrentPosition!.latitude, userCurrentPosition!.longitude);
    CameraPosition cameraPosition =
        CameraPosition(target: latlngPosition, zoom: 15);

    driverController.currentCamPosition = cameraPosition;
    if (driverController.mapController != null) {
      driverController.mapController!
          .animateCamera(CameraUpdate.newCameraPosition(cameraPosition));
    }

    setState(() {});

    // initailzeGeoFireListener();
    // AssistantMethods.readTripsKeyForOnlineUser(context);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (driverController.isTapedOnShowRoute.value == false) {
      locateUserPosition();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Home Screen',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            UserAccountsDrawerHeader(
              accountName: Obx(
                () => Text(driverController.driverModel.value.name),
              ),
              accountEmail: Text(driverController.driverModel.value.email),
              decoration: const BoxDecoration(
                color: Colors.blue,
              ),
            ),
            ListTile(
              title: const Text('Your Rides'),
              leading: const Icon(Icons.directions_car),
              onTap: () {
                Get.to(() => const DriverOwnRidesScreen());
              },
            ),
            ListTile(
              title: const Text('Driver Profile'),
              leading: const Icon(Icons.settings),
              onTap: () {
                Get.to(() => const DriverProfile());
              },
            ),
            ListTile(
              title: const Text('User Mode'),
              leading: const Icon(Icons.person),
              trailing: Obx(
                () => Switch(
                    value: userProfileController.userModel.value.role == 'User',
                    onChanged: (v) {
                      userProfileController.userModel.value =
                          userProfileController.userModel.value.copyWith(
                        role: 'User',
                      );
                      FirebaseFirestore.instance
                          .collection('users')
                          .doc(FirebaseAuth.instance.currentUser!.uid)
                          .update({'role': 'User'}).then((value) {
                        Get.offAll(() => const DashboardScreen(),
                            binding: UserBindings());
                      });
                    }),
              ),
              onTap: () {
                FirebaseAuth.instance.signOut().then((value) {
                  Get.offAll(() => const LoginScreen(),
                      binding: InitialBindings());
                });
              },
            ),
            ListTile(
              title: const Text('Logout'),
              leading: const Icon(Icons.logout),
              onTap: () {
                FirebaseAuth.instance.signOut().then((value) {
                  Get.offAll(() => const LoginScreen(),
                      binding: InitialBindings());
                });
              },
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          GetBuilder<DriverController>(builder: (cntlr) {
            return GoogleMap(
              mapType: MapType.normal,
              myLocationEnabled: true,
              zoomGesturesEnabled: true,
              zoomControlsEnabled: false,
              initialCameraPosition: driverController.currentCamPosition ??
                  const CameraPosition(target: LatLng(0, 0)),
              polylines: {
                Polyline(
                  polylineId: const PolylineId("poly"),
                  color: Colors.red,
                  points: cntlr.polylineCordinates,
                  width: 8,
                ),
              },
              markers: Set<Marker>.from(cntlr.allMarkers),
              onMapCreated: (GoogleMapController controller) {
                _controllerGoogleMap.complete(controller);
                driverController.mapController = controller;

                setState(() {
                  bottomPaddingOfMap = 200;
                });
                if (driverController.isTapedOnShowRoute.value == false) {
                  locateUserPosition();
                }
              },
              onCameraMove: (CameraPosition? position) {
                if (pickLocation != position!.target) {
                  setState(() {
                    pickLocation = position.target;
                  });
                }
              },
              onCameraIdle: () {
                // getAddressFromLatLng();
              },
            );
          }),
          // Align(
          //   alignment: Alignment.center,
          //   child: Padding(
          //     padding: const EdgeInsets.only(bottom: 35.0),
          //     child: Image.asset(
          //       "images/pick.png",
          //       height: 45,
          //       width: 45,
          //     ),
          //   ),
          // ),
          //Ui for searching location
          Positioned(
              bottom: 0,
              right: 0,
              left: 0,
              child: MyButton(
                onTap: () {
                  // showBottomSheet(
                  //     context, _suggestions); // Show the bottom sheet
                  Get.to(() => const DriverSelectPickUpScreen());
                },
                text: 'Add Ride',
              )
              // ElevatedButton(
              //   onPressed: () {
              //     _showBottomSheet(context); // Show the bottom sheet
              //   },
              //   child: const Text('Select Pickup'),
              // ),
              )

          // Positioned(
          //   bottom: 0,
          //   left: 0,
          //   right: 0,
          //   child: Padding(
          //     padding: const EdgeInsets.fromLTRB(20, 50, 20, 20),
          //     child: Column(
          //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //       children: [
          //         Container(
          //           padding: const EdgeInsets.all(10),
          //           decoration: BoxDecoration(
          //               color: darktheme ? Colors.black : Colors.white,
          //               borderRadius: BorderRadius.circular(10)),
          //           child: Column(
          //             children: [
          //               Container(
          //                 decoration: BoxDecoration(
          //                   color: darktheme
          //                       ? Colors.grey.shade900
          //                       : Colors.grey.shade100,
          //                   borderRadius: BorderRadius.circular(10),
          //                 ),
          //                 child: Column(
          //                   children: [
          //                     Padding(
          //                       padding: const EdgeInsets.all(5),
          //                       child: Row(
          //                         children: [
          //                           Icon(
          //                             Icons.location_on_outlined,
          //                             color: darktheme
          //                                 ? Colors.amber.shade400
          //                                 : Colors.blue,
          //                           ),
          //                           const SizedBox(
          //                             width: 10,
          //                           ),
          //                           Column(
          //                             crossAxisAlignment:
          //                                 CrossAxisAlignment.start,
          //                             children: [
          //                               Text(
          //                                 "From",
          //                                 style: TextStyle(
          //                                   color: darktheme
          //                                       ? Colors.amber.shade400
          //                                       : Colors.blue,
          //                                   fontSize: 12,
          //                                   fontWeight: FontWeight.bold,
          //                                 ),
          //                               ),
          //                               // Text(
          //                               //   Provider.of<Appinfo>(context)
          //                               //               .userPickUpLocation !=
          //                               //           null
          //                               //       ? "${(Provider.of<Appinfo>(context).userPickUpLocation!.locationName!).substring(0, 24)}..."
          //                               //       : "Not Getting Address",
          //                               //   style: const TextStyle(
          //                               //       color: Colors.grey,
          //                               //       fontSize: 14),
          //                               // )
          //                             ],
          //                           )
          //                         ],
          //                       ),
          //                     ),
          //                     const SizedBox(
          //                       height: 5,
          //                     ),
          //                     Divider(
          //                       height: 1,
          //                       thickness: 2,
          //                       color: darktheme
          //                           ? Colors.amber.shade400
          //                           : Colors.blue,
          //                     ),
          //                     const SizedBox(
          //                       height: 5,
          //                     ),
          //                     Padding(
          //                       padding: const EdgeInsets.all(5),
          //                       child: GestureDetector(
          //                         onTap: () async {
          //                           //go to search places screen
          //                           var responseFroemSearchScreen =
          //                               await Navigator.push(
          //                                   context,
          //                                   MaterialPageRoute(
          //                                       builder: (c) =>
          //                                           const SearchPlacessScreen()));
          //                           if (responseFroemSearchScreen ==
          //                               "obtainedDropoff") {
          //                             setState(() {
          //                               openNavigationDrawer = false;
          //                             });
          //                           }

          //                           // await drawPolyLineFromOriginToDestination(
          //                           //     darktheme);
          //                         },
          //                         child: Row(
          //                           children: [
          //                             Icon(
          //                               Icons.location_on_outlined,
          //                               color: darktheme
          //                                   ? Colors.amber.shade400
          //                                   : Colors.blue,
          //                             ),
          //                             const SizedBox(
          //                               width: 10,
          //                             ),
          //                             Column(
          //                               crossAxisAlignment:
          //                                   CrossAxisAlignment.start,
          //                               children: [
          //                                 Text(
          //                                   "To",
          //                                   style: TextStyle(
          //                                     color: darktheme
          //                                         ? Colors.amber.shade400
          //                                         : Colors.blue,
          //                                     fontSize: 12,
          //                                     fontWeight: FontWeight.bold,
          //                                   ),
          //                                 ),
          //                                 // Text(
          //                                 //   Provider.of<Appinfo>(context)
          //                                 //               .userDropOffLocation !=
          //                                 //           null
          //                                 //       ? Provider.of<Appinfo>(
          //                                 //               context)
          //                                 //           .userDropOffLocation!
          //                                 //           .locationName!
          //                                 //       : "Where to?",
          //                                 //   style: const TextStyle(
          //                                 //       color: Colors.grey,
          //                                 //       fontSize: 14),
          //                                 // )
          //                               ],
          //                             )
          //                           ],
          //                         ),
          //                       ),
          //                     )
          //                   ],
          //                 ),
          //               )
          //             ],
          //           ),
          //         )
          //       ],
          //     ),
          //   ),
          // ),
          //  Positioned(
          //    top: 40,
          //    right: 20,
          //    left: 20,
          //   child: Container(
          //      decoration: BoxDecoration(
          //       border: Border.all(color: Colors.black),
          //        color: Colors.white,
          //      ),
          //      padding: EdgeInsets.all(20),
          //      child:  Text (
          //        Provider.of<Appinfo> (context).userPickUpLocation != null
          //            ? (Provider.of<Appinfo>(context).userPickUpLocation!.locationName!).substring(0, 24) + "..."
          //            : "Not Getting Address",
          //     overflow: TextOverflow.visible, softWrap: true,
          //      ),
          //    ),
          // )
        ],
      ),
    );
  }
}
