import 'package:carpoling_1/Screens/user_panel/car_mechanic/user_car_mech_main_screen.dart';
import 'package:carpoling_1/Screens/user_panel/car_tow/user_car_tow_main_screen.dart';
import 'package:carpoling_1/bindings/bindings.dart';
import 'package:carpoling_1/widgets/dashboard_button.dart';
import 'package:carpoling_1/widgets/dashboard_card.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

import '../ride_share/user_main_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 53, 99, 121),
      appBar: AppBar(
        backgroundColor: Colors.yellow,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Choose Service',
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              'images/pngegg.png',
              scale: 4.5,
            ),
            DashboardButton(
              text: 'CARPOOLING',
              widget: const FaIcon(FontAwesomeIcons.car),
              onTap: () {
                Get.to(() => const UserMainScreen(), binding: UserBindings());
              },
            ),
            const SizedBox(
              height: 35,
            ),
            Image.asset(
              'images/car_mech_i2.png',
              scale: 4.5,
            ),
            const SizedBox(
              height: 15,
            ),
            DashboardButton(
              text: 'MECHANICS',
              widget: Icon(MdiIcons.tools),
              onTap: () {
                Get.to(() => const UserCarMechMainScreen(),
                    binding: CustomerCarMechanicBindings());
              },
            ),
            const SizedBox(
              height: 20,
            ),
            Image.asset(
              'images/cartow.png',
              scale: 4.5,
            ),
            DashboardButton(
              text: 'TOWING',
              widget: const FaIcon(FontAwesomeIcons.truckPickup),
              onTap: () {
                Get.to(() => const UserCarTowMainScreen(),
                    binding: CustomerCarTowBindings());
              },
            ),
          ],
        ),
      ),
    );
  }
}
