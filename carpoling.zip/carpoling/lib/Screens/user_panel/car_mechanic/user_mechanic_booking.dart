import 'package:carpoling_1/Screens/user_panel/car_mechanic/user_car_mech_main_screen.dart';
import 'package:carpoling_1/controller/user_controller/car_mechanic_controller/car_mechanic_controller.dart';
import 'package:carpoling_1/utils/utils.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/my_textfield.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart';

class CarMechanicBookingForm extends StatefulWidget {
  final String carMechanicId;

  final String carMechanicName;
  final String carMechanicEmail;
  final String carMechanicNum;
  const CarMechanicBookingForm({
    super.key,
    required this.carMechanicId,
    required this.carMechanicEmail,
    required this.carMechanicName,
    required this.carMechanicNum,
  });

  @override
  _CarMechanicBookingFormState createState() => _CarMechanicBookingFormState();
}

class _CarMechanicBookingFormState extends State<CarMechanicBookingForm> {
  final _formKey = GlobalKey<FormState>();
  bool _useCurrentLocation = true;
  Position? _currentPosition;
  LatLng? _selectedLocation;
  String? _address;
  UserCarMechanicController userCarMechanicController = Get.find();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _carNameController = TextEditingController();
  final TextEditingController _carModelController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _reasonController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (_useCurrentLocation) {
      _getCurrentLocation();
    }
  }

  Future<void> _getCurrentLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      setState(() {
        _currentPosition = position;
        _selectedLocation = LatLng(position.latitude, position.longitude);
        _getAddressFromLatLng(_selectedLocation!);
      });
    } catch (e) {
      print(e);
    }
  }

  Future<void> _getAddressFromLatLng(LatLng position) async {
    try {
      List<Placemark> placemarks =
          await placemarkFromCoordinates(position.latitude, position.longitude);
      if (placemarks.isNotEmpty) {
        Placemark placemark = placemarks.first;
        setState(() {
          _address =
              "${placemark.street}, ${placemark.locality}, ${placemark.administrativeArea}, ${placemark.country}";
          _addressController.text = _address!;
        });
      }
    } catch (e) {
      print(e);
    }
  }

  void _toggleLocation(bool value) {
    setState(() {
      _useCurrentLocation = value;
      if (_useCurrentLocation) {
        _getCurrentLocation();
      } else {
        _addressController.clear();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Car Mechanic Booking')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              MyTextField(
                controller: _nameController,
                hintText: 'User Name',
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your name';
                  }
                  return null;
                },
              ),
              MyTextField(
                controller: _emailController,
                hintText: 'User Email',
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email';
                  }
                  return null;
                },
              ),
              MyTextField(
                controller: _phoneController,
                hintText: 'User Phone',
                textInputType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your phone number';
                  }
                  return null;
                },
              ),
              MyTextField(
                controller: _carNameController,
                hintText: 'Car Name',
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your car name';
                  }
                  return null;
                },
              ),
              MyTextField(
                controller: _carModelController,
                textInputType: TextInputType.number,
                hintText: 'Car Model',
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your car model';
                  }
                  return null;
                },
              ),
              // SwitchListTile(
              //   title: const Text('Use my current location'),
              //   value: _useCurrentLocation,
              //   onChanged: (value) {
              //     _toggleLocation(value);
              //   },
              // ),
              MyTextField(
                controller: _addressController,
                hintText: 'Address',
                readOnly: _useCurrentLocation,
                validator: (value) {
                  if (!_useCurrentLocation &&
                      (value == null || value.isEmpty)) {
                    return 'Please enter your address';
                  }
                  return null;
                },
              ),
              MyTextField(
                controller: _reasonController,
                maxlines: 3,
                hintText: 'Reason for Car Repair',
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the reason for car repair';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              MyButton(
                  onTap: () async {
                    if (_formKey.currentState!.validate()) {
                      final docId =
                          DateTime.now().millisecondsSinceEpoch.toString();
                      Map<String, dynamic> data = {
                        'carMechanicName': widget.carMechanicName,
                        'carMechanicEmail': widget.carMechanicEmail,
                        'carMechanicNum': widget.carMechanicNum,
                        'customerName': _nameController.text,
                        'customerEmail': _emailController.text,
                        'customerPhone': _phoneController.text,
                        'customerAddress': _addressController.text,
                        'reasonForBooking': _reasonController.text,
                        'status': 'Pending',
                        'userId': FirebaseAuth.instance.currentUser!.uid,
                        'carMechanicId': widget.carMechanicId,
                        'timeOfRequest': DateTime.now(),
                        'docId': docId,
                      };
                      await FirebaseFirestore.instance
                          .collection('car_mechaninc_bookings')
                          .doc(docId)
                          .set(data)
                          .then((value) {
                        Get.back();
                        Get.back();
                      });
                      userCarMechanicController.customerCarMechanicBookings
                          .clear();
                      userCarMechanicController.showAllCarMechanicBookings();

                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text(
                                'Booking request submitted , Wait for Mechanic Status')),
                      );
                    }
                  },
                  text: 'Book Request'),
            ],
          ),
        ),
      ),
    );
  }
}
