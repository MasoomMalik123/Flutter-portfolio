import 'package:carpoling_1/Screens/driver_panel/driver_main_screen.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/user_main_screen.dart';
import 'package:carpoling_1/controller/driver_controller.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/controller/user_profile_controller.dart';
import 'package:carpoling_1/model/car_mech_booking_model.dart';
import 'package:carpoling_1/model/ride_model.dart';
import 'package:carpoling_1/utils/utils.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class CarMechBookDetailScreen extends StatefulWidget {
  final CarMechanicBookingModel carMechanicBookingModel;
  final bool isShowBookNowButton;
  const CarMechBookDetailScreen({
    super.key,
    required this.carMechanicBookingModel,
    this.isShowBookNowButton = false,
  });

  @override
  State<CarMechBookDetailScreen> createState() =>
      _CarMechBookDetailScreenState();
}

class _CarMechBookDetailScreenState extends State<CarMechBookDetailScreen> {
  var totalUsers = [];
  var totalRevenue = '0';
  var totalBookedSeats = '0';
  var totalAvailableSeats = '0';
  var pricePerSeat = '0';

  // DriverController driverController = Get.find<DriverController>();
  // UserController userController = Get.find<UserController>();
  UserProfileController userProfileController =
      Get.find<UserProfileController>();

  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   totalUsers.addAll(widget.rideModel.bookedRides);
  //   totalRevenue = widget.rideModel.driverRevenue;
  //   totalBookedSeats = widget.rideModel.driverBookedSeats;
  //   totalAvailableSeats = widget.rideModel.driverSeatsAvailable;
  //   pricePerSeat = widget.rideModel.pricePerSeat;
  //   print(widget.isShowBookNowButton);
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Car Mechanic Booking Details'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'images/mech_detail.png',
                scale: 1,
              ),
              const SizedBox(
                height: 30,
              ),
              RideTileRow(
                text1: 'Car Mechanic Name',
                text2: widget.carMechanicBookingModel.carMechanicName,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Car Mechanic Email',
                text2: widget.carMechanicBookingModel.carMechanicEmail,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking Time Request',
                text2: widget.carMechanicBookingModel.timeOfRequest.toString(),
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Car Mechanic Phone',
                text2: widget.carMechanicBookingModel.carMechanicNum,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking ID',
                text2: widget.carMechanicBookingModel.docId,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking Status',
                text2: widget.carMechanicBookingModel.status,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Reason For Booking',
                text2: widget.carMechanicBookingModel.reasonForBooking,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
