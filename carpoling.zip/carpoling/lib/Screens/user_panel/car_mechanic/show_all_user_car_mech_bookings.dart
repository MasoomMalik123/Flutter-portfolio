import 'package:carpoling_1/Screens/driver_panel/driver_ride_detail_screen.dart';
import 'package:carpoling_1/Screens/user_panel/car_mechanic/user_mech_book_detail_screen.dart';
import 'package:carpoling_1/controller/user_controller/car_mechanic_controller/car_mechanic_controller.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ShowAllUserCarMechanicBookings extends StatelessWidget {
  ShowAllUserCarMechanicBookings({super.key});

  UserCarMechanicController userCarMechanicController =
      Get.find<UserCarMechanicController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Available Car Mechanic Bookings'),
      ),
      body: Obx(
        () => ListView.builder(
          itemCount:
              userCarMechanicController.customerCarMechanicBookings.length,
          itemBuilder: ((context, index) {
            var carMechBooking =
                userCarMechanicController.customerCarMechanicBookings[index];
            return Container(
              margin: const EdgeInsets.all(15),
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.black)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  RideTileRow(
                    text1: 'Car Mechanic Name',
                    text2: carMechBooking.carMechanicName,
                    width: 10,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  RideTileRow(
                    text1: 'Car Mechanic Email',
                    text2: carMechBooking.carMechanicEmail,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  RideTileRow(
                    text1: 'Car Mechanic Num',
                    text2: carMechBooking.carMechanicNum,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  RideTileRow(
                    text1: 'Booking Status',
                    text2: carMechBooking.status,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  MyButton(
                      onTap: () {
                        Get.to(() => CarMechBookDetailScreen(
                              carMechanicBookingModel: carMechBooking,
                              isShowBookNowButton: true,
                            ));
                      },
                      text: 'Check Details'),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}
