import 'package:carpoling_1/Screens/driver_panel/driver_ride_detail_screen.dart';
import 'package:carpoling_1/Screens/user_panel/car_tow/user_car_tow_book_detail_screen.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/controller/user_controller/car_tow_controller/user_car_tow_controller.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ShowAllUserCarTowsBookings extends StatelessWidget {
  ShowAllUserCarTowsBookings({super.key});

  UserCarTowController userCarTowController = Get.find<UserCarTowController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Available Car Tow Bookings'),
      ),
      body: Obx(
        () => ListView.builder(
          itemCount: userCarTowController.customerCarTowBookings.length,
          itemBuilder: ((context, index) {
            var carTowBooking =
                userCarTowController.customerCarTowBookings[index];
            return Container(
              margin: const EdgeInsets.all(15),
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.black)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  RideTileRow(
                    text1: 'Car Tow Name',
                    text2: carTowBooking.carTowName,
                    width: 10,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  RideTileRow(
                    text1: 'Car Tow Email',
                    text2: carTowBooking.carTowEmail,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  RideTileRow(
                    text1: 'Car Tow Num',
                    text2: carTowBooking.carTowNum,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  RideTileRow(
                    text1: 'Booking Status',
                    text2: carTowBooking.status,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  MyButton(
                      onTap: () {
                        Get.to(() => CarTowBookUserDetailScreen(
                              carTowBookingModel: carTowBooking,
                              isShowBookNowButton: true,
                            ));
                      },
                      text: 'Check Details'),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}
