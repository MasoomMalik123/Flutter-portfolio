
import 'package:carpoling_1/controller/user_profile_controller.dart';
import 'package:carpoling_1/model/car_tow_booking_model.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CarTowBookUserDetailScreen extends StatefulWidget {
  final CarTowBookingModel carTowBookingModel;
  final bool isShowBookNowButton;
  const CarTowBookUserDetailScreen({
    super.key,
    required this.carTowBookingModel,
    this.isShowBookNowButton = false,
  });

  @override
  State<CarTowBookUserDetailScreen> createState() =>
      _CarTowBookUserDetailScreenState();
}

class _CarTowBookUserDetailScreenState extends State<CarTowBookUserDetailScreen> {
  var totalUsers = [];
  var totalRevenue = '0';
  var totalBookedSeats = '0';
  var totalAvailableSeats = '0';
  var pricePerSeat = '0';

  // DriverController driverController = Get.find<DriverController>();
  // UserController userController = Get.find<UserController>();
  UserProfileController userProfileController =
      Get.find<UserProfileController>();

  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   totalUsers.addAll(widget.rideModel.bookedRides);
  //   totalRevenue = widget.rideModel.driverRevenue;
  //   totalBookedSeats = widget.rideModel.driverBookedSeats;
  //   totalAvailableSeats = widget.rideModel.driverSeatsAvailable;
  //   pricePerSeat = widget.rideModel.pricePerSeat;
  //   print(widget.isShowBookNowButton);
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Car Tow Booking Details'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'images/cartow.png',
                scale: 2.5,
              ),
              const SizedBox(
                height: 30,
              ),
              RideTileRow(
                text1: 'Car Tow Name',
                text2: widget.carTowBookingModel.carTowName,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Car Tow Email',
                text2: widget.carTowBookingModel.carTowEmail,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking Time Request',
                text2: widget.carTowBookingModel.timeOfRequest.toString(),
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Car Tow Phone',
                text2: widget.carTowBookingModel.carTowNum,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking ID',
                text2: widget.carTowBookingModel.docId,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking Status',
                text2: widget.carTowBookingModel.status,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Reason For Booking',
                text2: widget.carTowBookingModel.reasonForBooking,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
