import 'package:carpoling_1/Screens/driver_panel/driver_ride_detail_screen.dart';
import 'package:carpoling_1/controller/driver_controller.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

const text1Style =
    TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black);
const text2Style =
    TextStyle(fontSize: 16, fontWeight: FontWeight.w400, color: Colors.black);

class UserBookedRides extends StatefulWidget {
  const UserBookedRides({super.key});

  @override
  State<UserBookedRides> createState() => _UserBookedRidesState();
}

class _UserBookedRidesState extends State<UserBookedRides> {
  UserController userController = Get.find<UserController>();
  @override
  Widget build(BuildContext context) {
    return Obx(() => Scaffold(
          body: SafeArea(
            child: userController.userBookedRide.isNotEmpty
                ? ListView.builder(
                    itemCount: userController.userBookedRide.length,
                    itemBuilder: ((context, index) {
                      var ride = userController.userBookedRide[index];
                      return Container(
                        margin: const EdgeInsets.all(15),
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.black)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            RideTileRow(
                              text1: 'From',
                              text2: ride.driverRideStartLocation,
                              width: 10,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            RideTileRow(
                              text1: 'To',
                              text2: ride.driverRideEndLocation,
                              width: 30,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            MyButton(
                                onTap: () {
                                  Get.to(() => DriverRideDetailScreen(
                                        rideModel: ride,
                                        isShowBookNowButton: true,
                                      ));
                                },
                                text: 'Check Details'),
                          ],
                        ),
                      );
                    }),
                  )
                : const Center(
                    child: Text(
                      'No Rides were booked by you',
                      style: text2Style,
                    ),
                  ),
          ),
        ));
  }
}
