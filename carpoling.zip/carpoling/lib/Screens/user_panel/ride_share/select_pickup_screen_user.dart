import 'dart:convert';

import 'package:carpoling_1/Global/map_key.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/model/ride_model.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/my_textfield.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class UserSelectPickUpScreen extends StatefulWidget {
  const UserSelectPickUpScreen({super.key});

  @override
  State<UserSelectPickUpScreen> createState() => _UserSelectPickUpScreenState();
}

class _UserSelectPickUpScreenState extends State<UserSelectPickUpScreen> {
  final TextEditingController _fromSearchController = TextEditingController();
  final TextEditingController _toSearchController = TextEditingController();

  List<Map<String, dynamic>> _fromSuggestions = [];
  List<Map<String, dynamic>> _toSuggestions = [];

  UserController userController = Get.find<UserController>();

  void _getFromPlaceSuggestions(String input) async {
    final apiUrl =
        'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$input&key=$mapKey';

    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final predictions = data['predictions'];

      setState(() {
        _fromSuggestions =
            predictions.map<Map<String, dynamic>>((dynamic prediction) {
          return {
            'description': prediction['description'] as String,
            'placeId': prediction['place_id'] as String,
            'lat': 0.0, // Initialize with a default value
            'lng': 0.0, // Initialize with a default value
          };
        }).toList();
      });
    }
  }

  void _getToPlaceSuggestions(String input) async {
    final apiUrl =
        'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$input&key=$mapKey';

    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final predictions = data['predictions'];

      setState(() {
        _toSuggestions =
            predictions.map<Map<String, dynamic>>((dynamic prediction) {
          return {
            'description': prediction['description'] as String,
            'placeId': prediction['place_id'] as String,
            'lat': 0.0, // Initialize with a default value
            'lng': 0.0, // Initialize with a default value
          };
        }).toList();
      });
    }
  }

  Future<void> _getPlaceDetails(String placeId, int index) async {
    final apiUrl =
        'https://maps.googleapis.com/maps/api/place/details/json?place_id=$placeId&key=$mapKey';

    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final location = data['result']['geometry']['location'];
      final double lat = location['lat'];
      final double lng = location['lng'];
      print("data");
      print(data);
      setState(() {
        // apiController.getDestLocation(lat, lng);
      });
      // apiController.isDestHasPoint.value = true;

      print('Selected place details - Lat: $lat, Lng: $lng');
    }
  }

  bool isShowFromLocation = false;
  bool isShowToLocation = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: const Text('Select Pickup'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                const Text(
                  'From:',
                  style: TextStyle(fontSize: 18),
                ),
                const SizedBox(height: 10),

                MyTextField(
                  controller: _fromSearchController,
                  hintText: 'Enter from location',
                  onTap: () {
                    isShowFromLocation = true;
                    isShowToLocation = false;
                    setState(() {});
                  },
                  onChanged: (value) {
                    setState(() {
                      _getFromPlaceSuggestions(value);
                    });
                  },
                ),
                const SizedBox(height: 10),
                const Text(
                  'To:',
                  style: TextStyle(fontSize: 18),
                ),
                const SizedBox(height: 10),

                MyTextField(
                  controller: _toSearchController,
                  hintText: 'Enter To location',
                  onTap: () {
                    isShowToLocation = true;
                    setState(() {});
                  },
                  onChanged: (value) {
                    setState(() {
                      _getToPlaceSuggestions(value);
                    });
                  },
                ),

                const SizedBox(height: 20),
                const Spacer(),
                // submit carbooking
                MyButton(
                    onTap: () async {
                      await userController.getAllRidesAvailableForUser(
                        fromLocation: _fromSearchController.text,
                        toLocation: _toSearchController.text,
                        context: context,
                      );
                    },
                    text: 'Find Ride')
              ],
            ),

            // from suggestions
            Visibility(
              visible: isShowFromLocation,
              child: Positioned(
                top: Get.height * .15,
                left: 0,
                right: 0,
                child: Container(
                  color: Colors.white,
                  height: Get.height * .25,
                  child: ListView.builder(
                    itemCount: _fromSuggestions.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(
                          _fromSuggestions[index]['description'] as String,
                          style: const TextStyle(color: Colors.black),
                        ),
                        onTap: () {
                          isShowFromLocation = false;
                          setState(() {});
                          _getPlaceDetails(
                              _fromSuggestions[index]['placeId'] as String,
                              index);
                          _fromSearchController.text =
                              _fromSuggestions[index]['description'] as String;
                          // Future.delayed(
                          //   Duration(seconds: 1),
                          // );
                          // print(
                          //     'is dest point getted : ${ctlr.isDestHasPoint.value}');

                          // if (ctlr.isDestHasPoint.value) {
                          //   ctlr.getDirection();
                          // }
                        },
                      );
                    },
                  ),
                ),
              ),
            ),

            // to suggestions
            Visibility(
              visible: isShowToLocation,
              child: Positioned(
                top: Get.height * .30,
                left: 0,
                right: 0,
                child: SizedBox(
                  height: Get.height * .25,
                  child: ListView.builder(
                    itemCount: _toSuggestions.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(
                          _toSuggestions[index]['description'] as String,
                          style: const TextStyle(color: Colors.black),
                        ),
                        onTap: () {
                          isShowToLocation = false;
                          setState(() {});
                          _getPlaceDetails(
                              _toSuggestions[index]['placeId'] as String,
                              index);
                          _toSearchController.text =
                              _toSuggestions[index]['description'] as String;
                          // Future.delayed(
                          //   Duration(seconds: 1),
                          // );
                          // print(
                          //     'is dest point getted : ${ctlr.isDestHasPoint.value}');

                          // if (ctlr.isDestHasPoint.value) {
                          //   ctlr.getDirection();
                          // }
                        },
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
