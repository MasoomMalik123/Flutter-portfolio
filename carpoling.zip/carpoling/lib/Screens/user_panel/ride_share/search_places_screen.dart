// import 'package:flutter/material.dart';


// import '../Assistance/request_assistant.dart';
// import '../models/predicted_places.dart';
// import '../widgets/place_prediction_tile.dart';

// class SearchPlacessScreen extends StatefulWidget {
//   const SearchPlacessScreen({super.key});

//   @override
//   State<SearchPlacessScreen> createState() => _SearchPlacessScreenState();
// }

// class _SearchPlacessScreenState extends State<SearchPlacessScreen> {
//   List<PredictedPlaces> placesPredictedList =[];

//   get mapkey => "AIzaSyAUVRf4UqY_OXvyI_D8DvDlWUsnkfAFR3c";


//   findPlaceAutoCompleteSearch(String inputText) async {
//     if(inputText.length >1){
//       String urlAutoCompleteSearch = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$inputText&key=$mapkey&components=country:PK";

//       var responseAutoCompleteSearch = await RequestAssistant.recieveRequest(urlAutoCompleteSearch);

//       if(responseAutoCompleteSearch == "Error Occures. Failed.No Response."){
//         return;
//       }
//       if(responseAutoCompleteSearch["status"]=="OK"){
//         var placePredictions = responseAutoCompleteSearch["predictions"];

//         var placePredictionList = (placePredictions as List).map((jsonData) => PredictedPlaces.fromJson(jsonData)).toList();

//         setState(() {
//           placesPredictedList = placePredictionList;
//         });

//       }
//     }

//   }


//   @override
//   Widget build(BuildContext context) {
//     bool darktheme = MediaQuery.of(context).platformBrightness == Brightness.dark;


//     return GestureDetector(
//       onTap: (){
//         FocusScope.of(context).unfocus();
//       },
//       child: Scaffold(
//         backgroundColor: darktheme ? Colors.black: Colors.white,
//         appBar: AppBar(
//           backgroundColor: darktheme ? Colors.amber.shade400 : Colors.blue,
//           leading: GestureDetector(
//             onTap: (){
//               Navigator.pop(context);
//             },
//             child: Icon(Icons.arrow_back, color: darktheme ? Colors.black : Colors.white,),

//           ),
//           title: Text(
//             "Search & Set droppoff Location",
//             style: TextStyle(color: darktheme ? Colors.black : Colors.white),

//           ),
//           elevation: 0.0,
//         ),
//         body: Column(
//           children:[
//             Container(
//               decoration: BoxDecoration(
//                 color: darktheme ? Colors.amber.shade400 : Colors.blue,
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.white54,
//                     blurRadius: 8,
//                     spreadRadius: 0.5,
//                     offset: Offset(
//                       0.7,
//                       0.7,
//                     )
//                   )
//                 ]
//               ),
//               child: Padding(
//                 padding: EdgeInsets.all(10.0),
//                 child: Column(
//                   children: [
//                     Row(
//                       children: [
//                         Icon(
//                             Icons.adjust_sharp,
//                           color: darktheme ? Colors.black : Colors.white,
//                         ),
//                         SizedBox(height:18.0 ,),

//                         Expanded(
//                             child: Padding(
//                               padding: EdgeInsets.all(8),
//                               child: TextField(
//                                 onChanged: (value){
//                                  findPlaceAutoCompleteSearch(value);

//                                 },
//                                 decoration: InputDecoration(
//                                   hintText: "Search Location here...",
//                                   fillColor: darktheme ? Colors.black : Colors.white54,
//                                   filled: true,
//                                   border: InputBorder.none,
//                                   contentPadding: EdgeInsets.only(
//                                     left: 11,
//                                     top: 8,
//                                     bottom: 8,
//                                   )
//                                 ),
//                               ),
//                             )
//                         )
//                       ],
//                     )
//                   ],
//                 ),
//               ),
//             ),
//             //display place prediction result
//               (placesPredictedList.length > 0)
//             ? Expanded(
//                 child: ListView.separated(
//                   itemCount: placesPredictedList.length,
//                   physics: ClampingScrollPhysics(),
//                   itemBuilder: (context, index){
//                     return PlacePredictionTileDesign(
//                       predictedPlaces: placesPredictedList[index] ,
//                     );

//                   },

//                   separatorBuilder: (BuildContext context, int index) {
//                     return Divider(
//                       height: 0,
//                       color: darktheme ? Colors.amber.shade400 : Colors.blue,
//                       thickness: 0,
//                     );
//                   },

//                 ),

//               ) : Container(),
//           ],
//         ),
//       ),
//     );
//   }
// }
