import 'package:carpoling_1/controller/user_profile_controller.dart';
import 'package:carpoling_1/model/user_model.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/my_textfield.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class UserEditProfile extends StatefulWidget {
  const UserEditProfile({super.key});

  @override
  State<UserEditProfile> createState() => _UserEditProfileState();
}

class _UserEditProfileState extends State<UserEditProfile> {
  UserProfileController userProfileController = Get.find();
  TextEditingController nameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    nameController.text = userProfileController.userModel.value.name;
    phoneController.text = userProfileController.userModel.value.phone;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(14.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              MyTextField(
                hintText: 'Name',
                controller: nameController,
              ),
              MyTextField(
                hintText: 'Phone',
                controller: phoneController,
              ),
              const SizedBox(
                height: 80,
              ),
              MyButton(
                  onTap: () async {
                    var model = userProfileController.userModel.value.copyWith(
                      name: nameController.text,
                      phone: phoneController.text,
                    );
                    userProfileController.updateUserModel(model);
                    await FirebaseFirestore.instance
                        .collection('users')
                        .doc(
                          FirebaseAuth.instance.currentUser!.uid,
                        )
                        .update({
                      'name': nameController.text,
                      'phone': phoneController.text,
                    }).then((v) {
                      Get.back();
                    });
                  },
                  text: 'Save Changes')
            ],
          ),
        ),
      ),
    );
  }
}
