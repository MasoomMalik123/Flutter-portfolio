import 'package:carpoling_1/Screens/driver_panel/driver_ride_detail_screen.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ShowAllRidesForUser extends StatelessWidget {
  ShowAllRidesForUser({super.key});

  UserController userController = Get.find<UserController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Available Rides'),
      ),
      body: ListView.builder(
        itemCount: userController.ridesForUser.length,
        itemBuilder: ((context, index) {
          var ride = userController.ridesForUser[index];
          return Container(
            margin: const EdgeInsets.all(15),
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.black)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                RideTileRow(
                  text1: 'From',
                  text2: ride.driverRideStartLocation,
                  width: 10,
                ),
                const SizedBox(
                  height: 15,
                ),
                RideTileRow(
                  text1: 'To',
                  text2: ride.driverRideEndLocation,
                  width: 30,
                ),
                const SizedBox(
                  height: 15,
                ),
                RideTileRow(
                  text1: 'Seat Price',
                  text2: ride.pricePerSeat,
                  width: 30,
                ),
                const SizedBox(
                  height: 30,
                ),
                MyButton(
                    onTap: () {
                      Get.to(() => DriverRideDetailScreen(
                            rideModel: ride,
                            isShowBookNowButton: true,
                          ));
                    },
                    text: 'Check Details'),
              ],
            ),
          );
        }),
      ),
    );
  }
}
