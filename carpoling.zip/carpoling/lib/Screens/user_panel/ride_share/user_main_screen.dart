import 'dart:convert';

import 'package:carpoling_1/Screens/auth/Login_screen.dart';
import 'package:carpoling_1/Screens/driver_panel/driver_main_screen.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/user_profile.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/search_places_screen.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/select_pickup_screen_user.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/user_booked_rides.dart';
import 'package:carpoling_1/bindings/bindings.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/controller/user_profile_controller.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/my_textfield.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'dart:async';
import 'package:geolocator/geolocator.dart';
// import 'package:location/location.dart' as loc;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'package:http/http.dart' as http;

class UserMainScreen extends StatefulWidget {
  const UserMainScreen({super.key});

  @override
  State<UserMainScreen> createState() => _UserMainScreenState();
}

class _UserMainScreenState extends State<UserMainScreen> {
  UserController userController = Get.find<UserController>();
  UserProfileController userProfileController =
      Get.find<UserProfileController>();

  LatLng? pickLocation;
  // loc.Location location = loc.Location();
  String? _address;

  final Completer<GoogleMapController> _controllerGoogleMap = Completer();
  // GoogleMapController? newGoogleMapController;

  // CameraPosition? _currentCamPosition;
  //  = CameraPosition(
  //   target: LatLng(37.42796133580664, -122.085749655962),
  //   zoom: 14.4746,
  // );
  final GlobalKey<ScaffoldState> _scaffoldstate = GlobalKey<ScaffoldState>();

  double searchLocationContainerHeight = 220;
  double waitingResponsefromDriverContainerHeight = 0;
  double assignedDriverInfoContainerHeight = 0;
  Position? userCurrentPosition;
  var geoLocation = Geolocator();
  LocationPermission? _locationPermission;
  double bottomPaddingOfMap = 0;
  List<LatLng> pLineCoordinatedList = [];
  Set<Polyline> polylineSet = {};
  Set<Marker> markersSet = {};
  Set<Circle> circlesSet = {};

  String userName = "";
  String userEmail = "";
  bool openNavigationDrawer = true;
  bool activeNearbyDriverKeysLoaded = false;
  BitmapDescriptor? activeNearbyIcon;

  locateUserPosition() async {
    Position cPostion = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    userCurrentPosition = cPostion;
    LatLng latlngPosition =
        LatLng(userCurrentPosition!.latitude, userCurrentPosition!.longitude);
    CameraPosition cameraPosition =
        CameraPosition(target: latlngPosition, zoom: 15);

    userController.currentCamPosition = cameraPosition;
    if (userController.mapController != null) {
      userController.mapController!
          .animateCamera(CameraUpdate.newCameraPosition(cameraPosition));
    }

    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    if (userController.isTapedOnShowRoute.value == false) {
      locateUserPosition();
    }
  }

  @override
  Widget build(BuildContext context) {
    // bool darktheme =
    //     MediaQuery.of(context).platformBrightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Home',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            UserAccountsDrawerHeader(
              accountName: Obx(
                () => Text(userProfileController.userModel.value.name),
              ),
              accountEmail: Text(userProfileController.userModel.value.email),
              decoration: const BoxDecoration(
                color: Colors.blue,
              ),
            ),
            ListTile(
              title: const Text('Your Rides'),
              leading: const Icon(Icons.directions_car),
              onTap: () {
                Get.to(() => const UserBookedRides());
              },
            ),
            ListTile(
              title: const Text('User Profile'),
              leading: const Icon(Icons.settings),
              onTap: () {
                Get.to(() => const UserProfile());
              },
            ),
            ListTile(
              title: const Text('Driver Mode'),
              leading: const Icon(Icons.person),
              trailing: Obx(
                () => Switch(
                    value:
                        userProfileController.userModel.value.role == 'Driver',
                    onChanged: (v) {
                      userProfileController.userModel.value =
                          userProfileController.userModel.value.copyWith(
                        role: 'Driver',
                      );
                      FirebaseFirestore.instance
                          .collection('users')
                          .doc(FirebaseAuth.instance.currentUser!.uid)
                          .update({'role': 'Driver'}).then((value) {
                        setState(() {});
                        Get.offAll(() => const DriverMainScreen(),
                            binding: DriverBindings());
                      });
                    }),
              ),
              onTap: () {
                FirebaseAuth.instance.signOut().then((value) {
                  Get.offAll(() => const LoginScreen(),
                      binding: InitialBindings());
                });
              },
            ),
            ListTile(
              title: const Text('Logout'),
              leading: const Icon(Icons.logout),
              onTap: () {
                FirebaseAuth.instance.signOut().then((value) {
                  Get.offAll(() => const LoginScreen(),
                      binding: InitialBindings());
                });
              },
            ),
          ],
        ),
      ),
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          GetBuilder<UserController>(builder: (cntlr) {
            return GoogleMap(
              mapType: MapType.normal,
              myLocationEnabled: true,
              zoomGesturesEnabled: true,
              zoomControlsEnabled: false,
              initialCameraPosition: userController.currentCamPosition ??
                  const CameraPosition(target: LatLng(0, 0)),
              polylines: {
                Polyline(
                  polylineId: const PolylineId("poly"),
                  color: Colors.red,
                  points: cntlr.polylineCordinates,
                  width: 8,
                ),
              },
              markers: Set<Marker>.from(cntlr.allMarkers),
              circles: circlesSet,
              onMapCreated: (GoogleMapController controller) {
                _controllerGoogleMap.complete(controller);
                userController.mapController = controller;

                setState(() {
                  bottomPaddingOfMap = 200;
                });

                if (userController.isTapedOnShowRoute.value == false) {
                  locateUserPosition();
                }
              },
              onCameraMove: (CameraPosition? position) {
                if (pickLocation != position!.target) {
                  setState(() {
                    pickLocation = position.target;
                  });
                }
              },
              onCameraIdle: () {
                // getAddressFromLatLng();
              },
            );
          }),
          // Align(
          //   alignment: Alignment.center,
          //   child: Padding(
          //     padding: const EdgeInsets.only(bottom: 35.0),
          //     child: Image.asset(
          //       "images/pick.png",
          //       height: 45,
          //       width: 45,
          //     ),
          //   ),
          // ),
          //Ui for searching location
          Positioned(
              bottom: 0,
              right: 0,
              left: 0,
              child: MyButton(
                onTap: () {
                  // showBottomSheet(
                  //     context, _suggestions); // Show the bottom sheet
                  Get.to(() => const UserSelectPickUpScreen());
                },
                text: 'Select Pickup',
              )
              // ElevatedButton(
              //   onPressed: () {
              //     _showBottomSheet(context); // Show the bottom sheet
              //   },
              //   child: const Text('Select Pickup'),
              // ),
              )
        ],
      ),
    );
  }
}
