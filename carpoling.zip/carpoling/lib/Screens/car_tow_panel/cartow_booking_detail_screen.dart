import 'package:carpoling_1/Global/colors.dart';

import 'package:carpoling_1/controller/cartow_controller/cartow_controller.dart';
import 'package:carpoling_1/controller/user_profile_controller.dart';
import 'package:carpoling_1/model/car_tow_booking_model.dart';
import 'package:carpoling_1/widgets/my_appbar.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/my_button2.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class CarTowBookDetailScreen extends StatefulWidget {
  CarTowBookingModel carTowBookingModel;
  final bool isShowBookNowButton;
  final int index;
  CarTowBookDetailScreen({
    super.key,
    required this.carTowBookingModel,
    this.isShowBookNowButton = false,
    required this.index,
  });

  @override
  State<CarTowBookDetailScreen> createState() => _CarTowBookDetailScreenState();
}

class _CarTowBookDetailScreenState extends State<CarTowBookDetailScreen> {
  var totalUsers = [];
  var totalRevenue = '0';
  var totalBookedSeats = '0';
  var totalAvailableSeats = '0';
  var pricePerSeat = '0';

  // UserController userController = Get.find<UserController>();
  UserProfileController userProfileController =
      Get.find<UserProfileController>();
  CarTowController carTowController = Get.find<CarTowController>();

  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   totalUsers.addAll(widget.rideModel.bookedRides);
  //   totalRevenue = widget.rideModel.driverRevenue;
  //   totalBookedSeats = widget.rideModel.driverBookedSeats;
  //   totalAvailableSeats = widget.rideModel.driverSeatsAvailable;
  //   pricePerSeat = widget.rideModel.pricePerSeat;
  //   print(widget.isShowBookNowButton);
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: myAppBar('Car Tow Booking Details'),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'images/cartow_self.png',
                scale: 2.5,
              ),
              const SizedBox(
                height: 20,
              ),
              RideTileRow(
                text1: 'Customer Name',
                text2: widget.carTowBookingModel.customerName,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Customer Email',
                text2: widget.carTowBookingModel.customerEmail,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking Status',
                text2: widget.carTowBookingModel.status,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking Time Request',
                text2: widget.carTowBookingModel.timeOfRequest.toString(),
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Customer Phone',
                text2: widget.carTowBookingModel.carTowNum,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking ID',
                text2: widget.carTowBookingModel.docId,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Customer Address',
                text2: widget.carTowBookingModel.customerAddress,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Reason For Booking',
                text2: widget.carTowBookingModel.reasonForBooking,
                width: 30,
              ),
              const SizedBox(
                height: 30,
              ),
              widget.carTowBookingModel.status == 'Pending'
                  ? Row(
                      children: [
                        Expanded(
                          child: MyBorderButton(
                            height: 42,
                            textSize: 14,
                            bgColor: kPrimaryColor,
                            textColor: Colors.blue,
                            borderColor: Colors.blue,
                            buttonText: 'Decline',
                            onTap: () {
                              var model =
                                  widget.carTowBookingModel.copyWith(
                                status: 'Decline',
                              );

                              carTowController.updateIndexOfModel(
                                  model,
                                  widget.index,
                                  widget.carTowBookingModel.docId,
                                  'Decline');

                              widget.carTowBookingModel = model;

                              setState(() {});
                            },
                          ),
                        ),
                        const SizedBox(
                          width: 8,
                        ),
                        Expanded(
                          child: MyButton2(
                            height: 42,
                            textSize: 14,
                            buttonText: 'Accept Order',
                            onTap: () {
                              var model =
                                  widget.carTowBookingModel.copyWith(
                                status: 'Accept',
                              );

                              carTowController.updateIndexOfModel(
                                  model,
                                  widget.index,
                                  widget.carTowBookingModel.docId,
                                  'Accept');

                              widget.carTowBookingModel = model;

                              setState(() {});
                            },
                          ),
                        ),
                      ],
                    )
                  : widget.carTowBookingModel.status == 'Decline'
                      ? MyButton(
                          text: 'Declined',
                          onTap: () {},
                        )
                      : widget.carTowBookingModel.status == 'Accept'
                          ? MyButton(
                              text: 'Accepted',
                              onTap: () {},
                            )
                          : const SizedBox.shrink(),
            ],
          ),
        ),
      ),
    );
  }
}
