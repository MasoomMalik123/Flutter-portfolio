// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';

// class CarTowOnBoard extends StatefulWidget {
//   const CarTowOnBoard({super.key});

//   @override
//   _CarTowOnBoardState createState() => _CarTowOnBoardState();
// }

// class _CarTowOnBoardState extends State<CarTowOnBoard> {
//   GoogleMapController? _controller;
//   Position? _currentPosition;
//   Marker? _currentMarker;
//   LatLng? _selectedLocation;

//   @override
//   void initState() {
//     super.initState();
//     _getCurrentLocation();
//   }

//   Future<void> _getCurrentLocation() async {
//     Position position = await Geolocator.getCurrentPosition(
//         desiredAccuracy: LocationAccuracy.high);
//     setState(() {
//       _currentPosition = position;
//       _selectedLocation = LatLng(position.latitude, position.longitude);
//     });
//   }

//   void _onMapCreated(GoogleMapController controller) {
//     _controller = controller;
//   }

//   void _onCameraMove(CameraPosition position) {
//     setState(() {
//       _selectedLocation = position.target;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Stack(
//         children: [
//           Column(
//             children: [
//               SizedBox(
//                 height: 200,
//                 child: _currentPosition == null
//                     ? const Center(child: CircularProgressIndicator())
//                     : GoogleMap(
//                         onMapCreated: _onMapCreated,
//                         initialCameraPosition: CameraPosition(
//                           target: LatLng(_currentPosition!.latitude,
//                               _currentPosition!.longitude),
//                           zoom: 14.0,
//                         ),
//                         onCameraMove: _onCameraMove,
//                         myLocationEnabled: true,
//                         myLocationButtonEnabled: true,
//                       ),
//               ),
//               Expanded(
//                 child: Center(
//                   child: _selectedLocation == null
//                       ? const Text('Move the map to select a location')
//                       : Text(
//                           'Selected Location: ${_selectedLocation!.latitude}, ${_selectedLocation!.longitude}'),
//                 ),
//               ),
//             ],
//           ),
//           Positioned(
//             top: 100,
//             left: MediaQuery.of(context).size.width / 2 - 20,
//             child: const Icon(Icons.location_on, color: Colors.black, size: 40),
//           ),
//         ],
//       ),
//     );

//   }
// }

import 'package:carpoling_1/Screens/car_tow_panel/cartow_main_screen.dart';
import 'package:carpoling_1/bindings/bindings.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:geoflutterfire_plus/geoflutterfire_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart';

class CarTowOnBoard extends StatefulWidget {
  const CarTowOnBoard({super.key});

  @override
  _CarTowOnBoardState createState() => _CarTowOnBoardState();
}

class _CarTowOnBoardState extends State<CarTowOnBoard> {
  GoogleMapController? _controller;
  Position? _currentPosition;
  LatLng? _selectedLocation;
  String? _address;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  Future<void> _getCurrentLocation() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    setState(() {
      _currentPosition = position;
      _selectedLocation = LatLng(position.latitude, position.longitude);
      _getAddressFromLatLng(_selectedLocation!);
    });
  }

  void _onMapCreated(GoogleMapController controller) {
    _controller = controller;
  }

  void _onCameraMove(CameraPosition position) {
    setState(() {
      _selectedLocation = position.target;
    });
  }

  void _onCameraIdle() {
    if (_selectedLocation != null) {
      _getAddressFromLatLng(_selectedLocation!);
    }
  }

  Future<void> _getAddressFromLatLng(LatLng position) async {
    try {
      List<Placemark> placemarks =
          await placemarkFromCoordinates(position.latitude, position.longitude);
      if (placemarks.isNotEmpty) {
        Placemark placemark = placemarks.first;
        setState(() {
          _address =
              "${placemark.street}, ${placemark.locality}, ${placemark.administrativeArea}, ${placemark.country}";
        });
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Select Car Tow Location',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(
                height: 20,
              ),
              const Text(
                'Move the Map To Select your Car Tow Location',
                style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                    fontWeight: FontWeight.w600),
              ),
              const SizedBox(
                height: 20,
              ),
              Stack(
                children: [
                  SizedBox(
                    height: 400,
                    child: _currentPosition == null
                        ? const Center(child: CircularProgressIndicator())
                        : GoogleMap(
                            onMapCreated: _onMapCreated,
                            initialCameraPosition: CameraPosition(
                              target: LatLng(_currentPosition!.latitude,
                                  _currentPosition!.longitude),
                              zoom: 14.0,
                            ),
                            onCameraMove: _onCameraMove,
                            onCameraIdle: _onCameraIdle,
                            myLocationEnabled: true,
                            myLocationButtonEnabled: true,
                          ),
                  ),
                  Positioned(
                    top: 185,
                    left: MediaQuery.of(context).size.width / 2 - 20,
                    child: Image.asset(
                      'images/cartow_self.png',
                      scale: 10,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Center(
                child: _address == null
                    ? const Text('Move the map to select a location')
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Selected Address: $_address',
                            style: const TextStyle(
                                fontSize: 18,
                                color: Colors.black,
                                fontWeight: FontWeight.w400),
                          ),
                          // Text(
                          //   'Selected LatLong: $_selectedLocation',
                          //   style: const TextStyle(
                          //       fontSize: 20,
                          //       color: Colors.black,
                          //       fontWeight: FontWeight.w600),
                          // ),
                        ],
                      ),
              ),
              const Spacer(),
              MyButton(
                  onTap: () async {
                    // Initialize GeoFlutterFire
                    if (_selectedLocation != null) {
                      final geo = GeoFirePoint(
                        GeoPoint(_selectedLocation!.latitude,
                            _selectedLocation!.longitude),
                      );

                      // Get the data map containing GeoPoint and geohash
                      final Map<String, dynamic> data = geo.data;

                      // Reference to Firestore
                      final firestore = FirebaseFirestore.instance;
                      Map<String, dynamic> mapData = {
                        'carTowMap': data,
                      };
                      await firestore
                          .collection('users')
                          .doc(FirebaseAuth.instance.currentUser!.uid)
                          .update(mapData)
                          .then((value) {
                        Get.offAll(() => const CarTowMainScreen(),
                            binding: CarTowBindings());
                      });
                    }
                  },
                  text: 'Finish'),
            ],
          ),
        ),
      ),
    );
  }
}
