import 'package:carpoling_1/Screens/car_mechanic_panel/mech_booking_detail_screen.dart';
import 'package:carpoling_1/Screens/car_tow_panel/cartow_booking_detail_screen.dart';
import 'package:carpoling_1/Screens/driver_panel/driver_ride_detail_screen.dart';
import 'package:carpoling_1/Screens/user_panel/car_mechanic/user_mech_book_detail_screen.dart';
import 'package:carpoling_1/controller/cartow_controller/cartow_controller.dart';
import 'package:carpoling_1/controller/mechanic_controller/mechanic_controller.dart';
import 'package:carpoling_1/controller/user_controller/car_mechanic_controller/car_mechanic_controller.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ShowAllCarTowsBookings extends StatelessWidget {
  ShowAllCarTowsBookings({super.key});

  CarTowController carTowController = Get.find<CarTowController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Available Car Tows Bookings'),
      ),
      body: Obx(
        () => ListView.builder(
          itemCount: carTowController.carTowBookings.length,
          itemBuilder: ((context, index) {
            var carTowBooking = carTowController.carTowBookings[index];
            return Container(
              margin: const EdgeInsets.all(15),
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.black)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  RideTileRow(
                    text1: 'Customer Name',
                    text2: carTowBooking.customerName,
                    width: 10,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  RideTileRow(
                    text1: 'Customer Email',
                    text2: carTowBooking.customerEmail,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  RideTileRow(
                    text1: 'Customer Num',
                    text2: carTowBooking.customerPhone,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  RideTileRow(
                    text1: 'Booking Status',
                    text2: carTowBooking.status,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  MyButton(
                      onTap: () {
                        Get.to(() => CarTowBookDetailScreen(
                              carTowBookingModel: carTowBooking,
                              isShowBookNowButton: true,
                              index: index,
                            ));
                      },
                      text: 'Check Details'),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}
