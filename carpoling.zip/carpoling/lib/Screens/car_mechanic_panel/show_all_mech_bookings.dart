import 'package:carpoling_1/Screens/car_mechanic_panel/mech_booking_detail_screen.dart';
import 'package:carpoling_1/Screens/driver_panel/driver_ride_detail_screen.dart';
import 'package:carpoling_1/Screens/user_panel/car_mechanic/user_mech_book_detail_screen.dart';
import 'package:carpoling_1/controller/mechanic_controller/mechanic_controller.dart';
import 'package:carpoling_1/controller/user_controller/car_mechanic_controller/car_mechanic_controller.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ShowAllMechanicBookings extends StatelessWidget {
  ShowAllMechanicBookings({super.key});

  MechanicController mechanicController = Get.find<MechanicController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Available Car Mechanic Bookings'),
      ),
      body: Obx(
        () => ListView.builder(
          itemCount: mechanicController.carMechanicBookings.length,
          itemBuilder: ((context, index) {
            var carMechBooking = mechanicController.carMechanicBookings[index];
            return Container(
              margin: const EdgeInsets.all(15),
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.black)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  RideTileRow(
                    text1: 'Customer Name',
                    text2: carMechBooking.customerName,
                    width: 10,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  RideTileRow(
                    text1: 'Customer Email',
                    text2: carMechBooking.customerEmail,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  RideTileRow(
                    text1: 'Customer Num',
                    text2: carMechBooking.customerPhone,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  RideTileRow(
                    text1: 'Booking Status',
                    text2: carMechBooking.status,
                    width: 30,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  MyButton(
                      onTap: () {
                        Get.to(() => MechBookDetailScreen(
                              carMechanicBookingModel: carMechBooking,
                              isShowBookNowButton: true,
                              index: index,
                            ));
                      },
                      text: 'Check Details'),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}
