import 'dart:convert';

import 'package:carpoling_1/Screens/auth/Login_screen.dart';
import 'package:carpoling_1/Screens/car_mechanic_panel/car_mech_profile.dart';
import 'package:carpoling_1/Screens/car_mechanic_panel/show_all_mech_bookings.dart';
import 'package:carpoling_1/Screens/user_panel/car_mechanic/show_all_user_car_mech_bookings.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/search_places_screen.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/select_pickup_screen_user.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/user_booked_rides.dart';
import 'package:carpoling_1/bindings/bindings.dart';
import 'package:carpoling_1/controller/mechanic_controller/mechanic_controller.dart';
import 'package:carpoling_1/controller/user_controller/car_mechanic_controller/car_mechanic_controller.dart';
import 'package:carpoling_1/controller/user_controller/car_tow_controller/user_car_tow_controller.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/controller/user_profile_controller.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/my_textfield.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'dart:async';
import 'package:geolocator/geolocator.dart';
// import 'package:location/location.dart' as loc;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'package:http/http.dart' as http;

class CarMechMainScreen extends StatefulWidget {
  const CarMechMainScreen({super.key});

  @override
  State<CarMechMainScreen> createState() => _CarMechMainScreenState();
}

class _CarMechMainScreenState extends State<CarMechMainScreen> {
  // UserController userController = Get.find<UserController>();
  MechanicController mechanicController = Get.find<MechanicController>();

  UserProfileController userProfileController =
      Get.find<UserProfileController>();

  LatLng? pickLocation;
  // loc.Location location = loc.Location();
  String? _address;

  final Completer<GoogleMapController> _controllerGoogleMap = Completer();
  // GoogleMapController? newGoogleMapController;

  // CameraPosition? _currentCamPosition;
  //  = CameraPosition(
  //   target: LatLng(37.42796133580664, -122.085749655962),
  //   zoom: 14.4746,
  // );
  final GlobalKey<ScaffoldState> _scaffoldstate = GlobalKey<ScaffoldState>();

  double searchLocationContainerHeight = 220;
  double waitingResponsefromDriverContainerHeight = 0;
  double assignedDriverInfoContainerHeight = 0;
  Position? userCurrentPosition;
  var geoLocation = Geolocator();
  LocationPermission? _locationPermission;
  double bottomPaddingOfMap = 0;
  List<LatLng> pLineCoordinatedList = [];
  Set<Polyline> polylineSet = {};
  Set<Marker> markersSet = {};
  Set<Circle> circlesSet = {};

  String userName = "";
  String userEmail = "";
  bool openNavigationDrawer = true;
  bool activeNearbyDriverKeysLoaded = false;
  BitmapDescriptor? activeNearbyIcon;

  // locateUserPosition() async {
  //   Position cPostion = await Geolocator.getCurrentPosition(
  //       desiredAccuracy: LocationAccuracy.high);
  //   userCurrentPosition = cPostion;
  //   LatLng latlngPosition =
  //       LatLng(userCurrentPosition!.latitude, userCurrentPosition!.longitude);
  //   CameraPosition cameraPosition =
  //       CameraPosition(target: latlngPosition, zoom: 15);

  //   userController.currentCamPosition = cameraPosition;
  //   if (userController.mapController != null) {
  //     userController.mapController!
  //         .animateCamera(CameraUpdate.newCameraPosition(cameraPosition));
  //   }

  //   setState(() {});
  // }

  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();

  //   // if (userController.isTapedOnShowRoute.value == false) {
  //   locateUserPosition();
  //   // }
  // }

  @override
  Widget build(BuildContext context) {
    // bool darktheme =
    //     MediaQuery.of(context).platformBrightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Car Mechanics',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            Obx(
              () => UserAccountsDrawerHeader(
                accountName: Obx(
                  () => Text(userProfileController.userModel.value.name),
                ),
                accountEmail: Text(userProfileController.userModel.value.email),
                decoration: const BoxDecoration(
                  color: Colors.blue,
                ),
              ),
            ),
            // ListTile(
            //   title: const Text('Your Rides'),
            //   leading: const Icon(Icons.directions_car),
            //   onTap: () {
            //     Get.to(() => const UserBookedRides());
            //   },
            // ),
            ListTile(
              title: const Text('Car Mech Profile'),
              leading: const Icon(Icons.settings),
              onTap: () {
                Get.to(() => const CarMechProfile());
              },
            ),
            ListTile(
              title: const Text('Logout'),
              leading: const Icon(Icons.logout),
              onTap: () {
                FirebaseAuth.instance.signOut().then((value) {
                  Get.offAll(() => const LoginScreen(),
                      binding: InitialBindings());
                });
              },
            ),
            ListTile(
              title: const Text('My Booking'),
              leading: const Icon(Icons.car_crash_outlined),
              onTap: () {
                Get.to(() => ShowAllMechanicBookings());
                // FirebaseAuth.instance.signOut().then((value) {
                //   Get.offAll(() => const LoginScreen(),
                //       binding: InitialBindings());
                // });
              },
            ),
          ],
        ),
      ),
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          // GetBuilder<UserCarTowController>(builder: (cntlr) {
          //   return GoogleMap(
          //     mapType: MapType.normal,
          //     myLocationEnabled: true,
          //     zoomGesturesEnabled: true,
          //     zoomControlsEnabled: false,
          //     initialCameraPosition: CameraPosition(
          //         target: userCarTowController.userCurrentLatLng.value),
          //     // polylines: {
          //     //   Polyline(
          //     //     polylineId: const PolylineId("poly"),
          //     //     color: Colors.red,
          //     //     points: cntlr.polylineCordinates,
          //     //     width: 8,
          //     //   ),
          //     // },
          //     markers: Set<Marker>.from(cntlr.markers),
          //     circles: circlesSet,
          //     onMapCreated: (GoogleMapController controller) {
          //       _controllerGoogleMap.complete(controller);
          //       cntlr.mapController = controller;

          //       setState(() {
          //         bottomPaddingOfMap = 200;
          //       });

          //       // if (userController.isTapedOnShowRoute.value == false) {
          //       // }
          //       cntlr.getCarTowsStreams(cntlr.userCurrentLatLng.value);
          //     },
          //     onCameraMove: (CameraPosition? position) {
          //       if (pickLocation != position!.target) {
          //         setState(() {
          //           pickLocation = position.target;
          //         });
          //       }
          //     },
          //     onCameraIdle: () {
          //       // getAddressFromLatLng();
          //     },
          //   );
          // }),
          GetBuilder<MechanicController>(
            init: MechanicController(),
            builder: (cntlr) =>
                cntlr.userCurrentLatLng.value == const LatLng(0, 0)
                    ? const Center(child: CircularProgressIndicator())
                    : GoogleMap(
                        onMapCreated: (GoogleMapController controller) {
                          _controllerGoogleMap.complete(controller);
                          cntlr.mapController = controller;
                          print(
                              'This is the user location on Home Map : ${cntlr.userCurrentLatLng.value}');
                          mechanicController.getCarMechanicStreams(
                              mechanicController.userCurrentLatLng.value);
                        },
                        initialCameraPosition: CameraPosition(
                          target: cntlr.userCurrentLatLng.value,
                          zoom: 12.0,
                        ),
                        markers: Set<Marker>.of(cntlr.markers),
                        myLocationEnabled: true,
                        myLocationButtonEnabled: true,
                      ),
          ),
          // //Ui for searching location
          // Positioned(
          //     bottom: 0,
          //     right: 0,
          //     left: 0,
          //     child: MyButton(
          //       onTap: () {
          //         showModalBottomSheet(
          //           context: context,
          //           isScrollControlled: true,
          //           builder: (context) {
          //             return DraggableScrollableSheet(
          //               initialChildSize: 0.5,
          //               minChildSize: 0.3,
          //               maxChildSize: 1.0,
          //               expand: false,
          //               builder: (context, scrollController) {
          //                 return SingleChildScrollView(
          //                   controller: scrollController,
          //                   child: Container(
          //                     padding: const EdgeInsets.all(16.0),
          //                     child: Column(
          //                       crossAxisAlignment: CrossAxisAlignment.start,
          //                       children: <Widget>[
          //                         const Text(
          //                           'Bottom Sheet Content',
          //                           style: TextStyle(
          //                             fontSize: 24.0,
          //                             fontWeight: FontWeight.bold,
          //                           ),
          //                         ),
          //                         const SizedBox(height: 20.0),
          //                         const Text(
          //                           'This is a bottom sheet that can be dragged to expand fully.',
          //                           style: TextStyle(fontSize: 18.0),
          //                         ),
          //                         const SizedBox(height: 20.0),
          //                         for (int i = 0; i < 20; i++)
          //                           ListTile(
          //                             title: Text('Item $i'),
          //                           ),
          //                       ],
          //                     ),
          //                   ),
          //                 );
          //               },
          //             );
          //           },
          //         );
          //       },
          //       text: 'Show All Car Tows',
          //     )
          //     // ElevatedButton(
          //     //   onPressed: () {
          //     //     _showBottomSheet(context); // Show the bottom sheet
          //     //   },
          //     //   child: const Text('Select Pickup'),
          //     // ),
          //     )
        ],
      ),
    );
  }
}
