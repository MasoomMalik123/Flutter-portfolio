import 'package:carpoling_1/Global/colors.dart';
import 'package:carpoling_1/Screens/driver_panel/driver_main_screen.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/user_main_screen.dart';
import 'package:carpoling_1/controller/driver_controller.dart';
import 'package:carpoling_1/controller/mechanic_controller/mechanic_controller.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/controller/user_profile_controller.dart';
import 'package:carpoling_1/model/car_mech_booking_model.dart';
import 'package:carpoling_1/model/ride_model.dart';
import 'package:carpoling_1/utils/utils.dart';
import 'package:carpoling_1/widgets/my_appbar.dart';
import 'package:carpoling_1/widgets/my_button.dart';
import 'package:carpoling_1/widgets/my_button2.dart';
import 'package:carpoling_1/widgets/mytext.dart';
import 'package:carpoling_1/widgets/ride_tile_row.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MechBookDetailScreen extends StatefulWidget {
  CarMechanicBookingModel carMechanicBookingModel;
  final bool isShowBookNowButton;
  final int index;
  MechBookDetailScreen({
    super.key,
    required this.carMechanicBookingModel,
    this.isShowBookNowButton = false,
    required this.index,
  });

  @override
  State<MechBookDetailScreen> createState() => _MechBookDetailScreenState();
}

class _MechBookDetailScreenState extends State<MechBookDetailScreen> {
  var totalUsers = [];
  var totalRevenue = '0';
  var totalBookedSeats = '0';
  var totalAvailableSeats = '0';
  var pricePerSeat = '0';

  // UserController userController = Get.find<UserController>();
  UserProfileController userProfileController =
      Get.find<UserProfileController>();
  MechanicController mechanicController = Get.find<MechanicController>();

  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   totalUsers.addAll(widget.rideModel.bookedRides);
  //   totalRevenue = widget.rideModel.driverRevenue;
  //   totalBookedSeats = widget.rideModel.driverBookedSeats;
  //   totalAvailableSeats = widget.rideModel.driverSeatsAvailable;
  //   pricePerSeat = widget.rideModel.pricePerSeat;
  //   print(widget.isShowBookNowButton);
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: myAppBar('Car Mechanic Booking Details'),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'images/mech_detail.png',
                scale: 1.5,
              ),
              const SizedBox(
                height: 30,
              ),
              RideTileRow(
                text1: 'Customer Name',
                text2: widget.carMechanicBookingModel.customerName,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Customer Email',
                text2: widget.carMechanicBookingModel.customerEmail,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking Status',
                text2: widget.carMechanicBookingModel.status,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking Time Request',
                text2: widget.carMechanicBookingModel.timeOfRequest.toString(),
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Customer Phone',
                text2: widget.carMechanicBookingModel.carMechanicNum,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Booking ID',
                text2: widget.carMechanicBookingModel.docId,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Customer Address',
                text2: widget.carMechanicBookingModel.customerAddress,
                width: 30,
              ),
              const SizedBox(
                height: 10,
              ),
              RideTileRow(
                text1: 'Reason For Booking',
                text2: widget.carMechanicBookingModel.reasonForBooking,
                width: 30,
              ),
              const SizedBox(
                height: 30,
              ),
              widget.carMechanicBookingModel.status == 'Pending'
                  ? Row(
                      children: [
                        Expanded(
                          child: MyBorderButton(
                            height: 42,
                            textSize: 14,
                            bgColor: kPrimaryColor,
                            textColor: Colors.blue,
                            borderColor: Colors.blue,
                            buttonText: 'Decline',
                            onTap: () {
                              var model =
                                  widget.carMechanicBookingModel.copyWith(
                                status: 'Decline',
                              );

                              mechanicController.updateIndexOfModel(
                                  model,
                                  widget.index,
                                  widget.carMechanicBookingModel.docId,
                                  'Decline');

                              widget.carMechanicBookingModel = model;

                              setState(() {});
                            },
                          ),
                        ),
                        const SizedBox(
                          width: 8,
                        ),
                        Expanded(
                          child: MyButton2(
                            height: 42,
                            textSize: 14,
                            buttonText: 'Accept Order',
                            onTap: () {
                              var model =
                                  widget.carMechanicBookingModel.copyWith(
                                status: 'Accept',
                              );

                              mechanicController.updateIndexOfModel(
                                  model,
                                  widget.index,
                                  widget.carMechanicBookingModel.docId,
                                  'Accept');

                              widget.carMechanicBookingModel = model;

                              setState(() {});
                            },
                          ),
                        ),
                      ],
                    )
                  : widget.carMechanicBookingModel.status == 'Decline'
                      ? MyButton(
                          text: 'Declined',
                          onTap: () {},
                        )
                      : widget.carMechanicBookingModel.status == 'Accept'
                          ? MyButton(
                              text: 'Accepted',
                              onTap: () {},
                            )
                          : const SizedBox.shrink(),
            ],
          ),
        ),
      ),
    );
  }
}
