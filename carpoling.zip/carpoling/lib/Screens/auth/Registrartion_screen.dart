import 'package:carpoling_1/Screens/auth/verification_screen.dart';
import 'package:carpoling_1/Screens/car_mechanic_panel/car_mechanic_onboard.dart';
import 'package:carpoling_1/Screens/car_tow_panel/car_tow_onboard.dart';
import 'package:carpoling_1/Screens/user_panel/dashboard/dashboard.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/user_main_screen.dart';
import 'package:carpoling_1/bindings/bindings.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:email_validator/email_validator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

import '../../Global/global.dart';
import 'Login_screen.dart';
import 'forgot_password_screen.dart';
import '../driver_panel/driver_main_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final nameTextEditingController = TextEditingController();
  final emailTextEditingController = TextEditingController();
  final phoneTextEditingController = TextEditingController();
  final addressTextEditingController = TextEditingController();
  final passwordTextEditingController = TextEditingController();
  final confirmpasswordTextEditingController = TextEditingController();

  bool _passwordvisible = false;

  //declare a GlobalKey
  final _formkey = GlobalKey<FormState>();
  String selectedRole = 'User';
  final _auth = FirebaseAuth.instance;
  Future<bool> isEmailVerified(String email) async {
    User? user = _auth.currentUser;
    await user?.reload();
    return user?.emailVerified ?? false;
  }

  void _submit() async {
    // validate all the form Fields
    if (_formkey.currentState!.validate()) {
      // Proceed with sign-up
      await firebaseAuth
          .createUserWithEmailAndPassword(
              email: emailTextEditingController.text.trim(),
              password: passwordTextEditingController.text.trim())
          .then((auth) async {
        currentUser = auth.user;
        currentUser!.sendEmailVerification().then((value) {
          Fluttertoast.showToast(msg: "Check Email to Verify Your Account");
        });
        // User? user = _auth.currentUser;
        // await user?.sendEmailVerification();

        if (currentUser != null) {
          Map<String, dynamic> userMap = {
            "id": currentUser!.uid,
            "name": nameTextEditingController.text.trim(),
            "email": emailTextEditingController.text.trim(),
            "role": selectedRole,
            "phone": phoneTextEditingController.text.trim(),
            "isVerified": currentUser!.emailVerified,
          };
          FirebaseFirestore.instance
              .collection('users')
              .doc(currentUser!.uid)
              .set(userMap)
              .whenComplete(() {
            if (currentUser!.emailVerified) {
              Fluttertoast.showToast(msg: "Successfully Registered");
              if (selectedRole == 'User') {
                // Get.offAll(
                //   () => const UserMainScreen(),
                // );
                Get.offAll(() => const DashboardScreen(),
                    binding: UserBindings());
              } else if (selectedRole == 'Driver') {
                // Get.offAll(
                //   () => const DriverMainScreen(),
                // );
                Get.offAll(() => const DriverMainScreen(),
                    binding: DriverBindings());
              } else if (selectedRole == 'Car Mechanic') {
                Get.to(() => const CarMechanicOnBoard());
                // Get.offAll(
                //   () => const DriverMainScreen(),
                // );
                // Get.offAll(() => const DriverMainScreen(),
                //     binding: DriverBindings());
              } else if (selectedRole == 'Car Tow') {
                // Get.offAll(
                //   () => const DriverMainScreen(),
                // );
                Get.to(() => const CarTowOnBoard());
              }
            }
          });
          // DatabaseReference userRef =
          //     FirebaseDatabase.instance.ref().child("users");
          // userRef.child(currentUser!.uid).set(userMap);
        }

        // Navigator.push(
        //     context, MaterialPageRoute(builder: (c) => const MainScreen()));
      }).catchError((errorMessage) {
        Fluttertoast.showToast(msg: "Error occured: \n $errorMessage");
      });
    } else {
      Fluttertoast.showToast(msg: "Not all field are valid");
    }
  }

  @override
  Widget build(BuildContext context) {
    bool darktheme =
        MediaQuery.of(context).platformBrightness == Brightness.dark;

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        body: ListView(
          padding: const EdgeInsets.all(0),
          children: [
            Column(
              children: [
                Image.asset(
                    darktheme ? 'images/city_dark.jpg' : 'images/city.jpg'),
                const SizedBox(
                  height: 20,
                ),
                Text(
                  'Register',
                  style: TextStyle(
                    color: darktheme ? Colors.amber.shade400 : Colors.blue,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(
                      15, 20, 15, 50), //Left Top right Bootm
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Form(
                        key: _formkey,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            TextFormField(
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(50)
                              ],
                              decoration: InputDecoration(
                                hintText: "Name",
                                hintStyle: const TextStyle(
                                  color: Colors.grey,
                                ),
                                filled: true,
                                fillColor: darktheme
                                    ? Colors.black45
                                    : Colors.grey.shade200,
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(40),
                                    borderSide: const BorderSide(
                                      width: 0,
                                      style: BorderStyle.none,
                                    )),
                                prefixIcon: Icon(
                                  Icons.person,
                                  color: darktheme
                                      ? Colors.amber.shade400
                                      : Colors.grey,
                                ),
                              ),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (text) {
                                if (text == null || text.isEmpty) {
                                  return 'Name can not be empty';
                                }
                                if (text.length < 2) {
                                  return "Please enter a valid name";
                                }
                                if (text.length > 50) {
                                  return "Name can not be more then 50 ";
                                }
                                return null;
                              },
                              onChanged: (text) => setState(() {
                                nameTextEditingController.text = text;
                              }),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            TextFormField(
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(100)
                              ],
                              decoration: InputDecoration(
                                hintText: "Email",
                                hintStyle: const TextStyle(
                                  color: Colors.grey,
                                ),
                                filled: true,
                                fillColor: darktheme
                                    ? Colors.black45
                                    : Colors.grey.shade200,
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(40),
                                    borderSide: const BorderSide(
                                      width: 0,
                                      style: BorderStyle.none,
                                    )),
                                prefixIcon: Icon(
                                  Icons.person,
                                  color: darktheme
                                      ? Colors.amber.shade400
                                      : Colors.grey,
                                ),
                              ),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (text) {
                                if (text == null || text.isEmpty) {
                                  return 'Email can not be empty';
                                }
                                if (text.length < 2) {
                                  return "Please enter a valid Email";
                                }
                                if (EmailValidator.validate(text) == true) {
                                  return null;
                                }
                                if (text.length > 100) {
                                  return "Email can not be more then 100 ";
                                }
                                return null;
                              },
                              onChanged: (text) => setState(() {
                                emailTextEditingController.text =
                                    text; //write text
                              }),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            IntlPhoneField(
                              showCountryFlag: false,
                              dropdownIcon: Icon(
                                Icons.arrow_drop_down,
                                color: darktheme
                                    ? Colors.amber.shade400
                                    : Colors.grey,
                              ),
                              decoration: InputDecoration(
                                hintText: "Phone",
                                hintStyle: const TextStyle(
                                  color: Colors.grey,
                                ),
                                filled: true,
                                fillColor: darktheme
                                    ? Colors.black45
                                    : Colors.grey.shade200,
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(40),
                                    borderSide: const BorderSide(
                                      width: 0,
                                      style: BorderStyle.none,
                                    )),
                              ),
                              initialCountryCode: 'PK',
                              onChanged: (text) => setState(() {
                                phoneTextEditingController.text =
                                    text.completeNumber; //write text
                              }),
                            ),
                            // TextFormField(
                            //   inputFormatters: [
                            //     LengthLimitingTextInputFormatter(50)
                            //   ],
                            //   decoration: InputDecoration(
                            //     hintText: "Address",
                            //     hintStyle: const TextStyle(
                            //       color: Colors.grey,
                            //     ),
                            //     filled: true,
                            //     fillColor: darktheme
                            //         ? Colors.black45
                            //         : Colors.grey.shade200,
                            //     border: OutlineInputBorder(
                            //         borderRadius: BorderRadius.circular(40),
                            //         borderSide: const BorderSide(
                            //           width: 0,
                            //           style: BorderStyle.none,
                            //         )),
                            //     prefixIcon: Icon(
                            //       Icons.person,
                            //       color: darktheme
                            //           ? Colors.amber.shade400
                            //           : Colors.grey,
                            //     ),
                            //   ),
                            //   autovalidateMode:
                            //       AutovalidateMode.onUserInteraction,
                            //   validator: (text) {
                            //     if (text == null || text.isEmpty) {
                            //       return 'Address can not be empty';
                            //     }
                            //     if (text.length < 2) {
                            //       return "Please enter a valid Address";
                            //     }
                            //     if (text.length > 50) {
                            //       return " Address can not be more then 50 ";
                            //     }
                            //     return null;
                            //   },
                            //   onChanged: (text) => setState(() {
                            //     addressTextEditingController.text = text;
                            //   }),
                            // ),
                            // const SizedBox(
                            //   height: 20,
                            // ),
                            TextFormField(
                              obscureText: !_passwordvisible,
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(50)
                              ],
                              decoration: InputDecoration(
                                  hintText: "Password",
                                  hintStyle: const TextStyle(
                                    color: Colors.grey,
                                  ),
                                  filled: true,
                                  fillColor: darktheme
                                      ? Colors.black45
                                      : Colors.grey.shade200,
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(40),
                                      borderSide: const BorderSide(
                                        width: 0,
                                        style: BorderStyle.none,
                                      )),
                                  prefixIcon: Icon(
                                    Icons.person,
                                    color: darktheme
                                        ? Colors.amber.shade400
                                        : Colors.grey,
                                  ),
                                  suffixIcon: IconButton(
                                      icon: Icon(
                                        _passwordvisible
                                            ? Icons.visibility
                                            : Icons.visibility_off,
                                        color: darktheme
                                            ? Colors.amber.shade400
                                            : Colors.grey,
                                      ),
                                      onPressed: () {
                                        //Update the state
                                        setState(() {
                                          _passwordvisible = !_passwordvisible;
                                        });
                                      })),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (text) {
                                if (text == null || text.isEmpty) {
                                  return 'Password can not be empty';
                                }
                                if (text.length < 2) {
                                  return "Please enter a valid Password";
                                }
                                if (text.length > 50) {
                                  return "Password can not be more then 50 ";
                                }
                                return null;
                              },
                              onChanged: (text) => setState(() {
                                passwordTextEditingController.text = text;
                              }),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            TextFormField(
                              obscureText: !_passwordvisible,
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(50)
                              ],
                              decoration: InputDecoration(
                                  hintText: "Confirm Password",
                                  hintStyle: const TextStyle(
                                    color: Colors.grey,
                                  ),
                                  filled: true,
                                  fillColor: darktheme
                                      ? Colors.black45
                                      : Colors.grey.shade200,
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(40),
                                      borderSide: const BorderSide(
                                        width: 0,
                                        style: BorderStyle.none,
                                      )),
                                  prefixIcon: Icon(
                                    Icons.person,
                                    color: darktheme
                                        ? Colors.amber.shade400
                                        : Colors.grey,
                                  ),
                                  suffixIcon: IconButton(
                                      icon: Icon(
                                        _passwordvisible
                                            ? Icons.visibility
                                            : Icons.visibility_off,
                                        color: darktheme
                                            ? Colors.amber.shade400
                                            : Colors.grey,
                                      ),
                                      onPressed: () {
                                        //Update the state
                                        setState(() {
                                          _passwordvisible = !_passwordvisible;
                                        });
                                      })),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (text) {
                                if (text == null || text.isEmpty) {
                                  return 'Confirm Password can not be empty';
                                }
                                if (text !=
                                    passwordTextEditingController.text) {
                                  return "Password do not match";
                                }
                                if (text.length < 6) {
                                  return "Please enter a valid Password";
                                }
                                if (text.length > 50) {
                                  return "Re-Password can not be more then 50 ";
                                }
                                return null;
                              },
                              onChanged: (text) => setState(() {
                                confirmpasswordTextEditingController.text =
                                    text;
                              }),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            DropdownButtonFormField<String>(
                              value: selectedRole,
                              onChanged: (String? newValue) {
                                setState(() {
                                  selectedRole = newValue!;
                                });
                              },
                              decoration: InputDecoration(
                                hintText: "Select Role",
                                hintStyle: const TextStyle(
                                  color: Colors.grey,
                                ),
                                filled: true,
                                fillColor: darktheme
                                    ? Colors.black45
                                    : Colors.grey.shade200,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(40),
                                  borderSide: const BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                  ),
                                ),
                                prefixIcon: Icon(
                                  Icons.person,
                                  color: darktheme
                                      ? Colors.amber.shade400
                                      : Colors.grey,
                                ),
                              ),
                              items: <String>[
                                'User',
                                'Driver',
                                'Car Mechanic',
                                'Car Tow',
                              ].map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please select a role';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    foregroundColor:
                                        darktheme ? Colors.black : Colors.white,
                                    backgroundColor: darktheme
                                        ? Colors.amber.shade400
                                        : Colors.blue,
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(32),
                                    ),
                                    minimumSize:
                                        const Size(double.infinity, 50)),
                                onPressed: () {
                                  _submit();
                                },
                                child: const Text(
                                  'Register',
                                  style: TextStyle(
                                    fontSize: 20,
                                  ),
                                )),
                            const SizedBox(
                              height: 20,
                            ),
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (c) =>
                                            const ForgotPasswordScreen()));
                              },
                              child: Text(
                                'Forgot Password',
                                style: TextStyle(
                                  color: darktheme
                                      ? Colors.amber.shade400
                                      : Colors.blue,
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text(
                                  "Have an account?",
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 15,
                                  ),
                                ),
                                const SizedBox(
                                  width: 5,
                                ),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (c) =>
                                                const LoginScreen()));
                                  },
                                  child: Text(
                                    "Sign in",
                                    style: TextStyle(
                                      fontSize: 15,
                                      color: darktheme
                                          ? Colors.amber.shade400
                                          : Colors.blue,
                                    ),
                                  ),
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
