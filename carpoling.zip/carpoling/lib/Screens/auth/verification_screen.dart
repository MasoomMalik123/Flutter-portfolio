import 'dart:async';

import 'package:carpoling_1/Screens/auth/Login_screen.dart';
import 'package:carpoling_1/Screens/car_mechanic_panel/mech_main_screen.dart';
import 'package:carpoling_1/Screens/car_tow_panel/cartow_main_screen.dart';
import 'package:carpoling_1/Screens/user_panel/dashboard/dashboard.dart';
import 'package:carpoling_1/bindings/bindings.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

class VerificationScreen extends StatefulWidget {
  const VerificationScreen({super.key});

  @override
  State<VerificationScreen> createState() => _VerificationScreenState();
}

class _VerificationScreenState extends State<VerificationScreen> {
  final _auth = FirebaseAuth.instance;
  late Timer timer;

  // veryfyingUser() async {
  //   FirebaseAuth.instance.authStateChanges().listen((event) async {
  //     if (event == null) {
  //       Get.to(() => const LoginScreen());
  //     } else {
  //       if (event.emailVerified == true) {
  //         // email is verified
  //         // return const HomeScreen();
  //         var docData = await FirebaseFirestore.instance
  //             .collection('users')
  //             .doc(event.uid)
  //             .get();
  //         var mapData = docData.data() as Map<String, dynamic>;
  //         if (mapData['role'] == 'User') {
  //           // Get.offAll(() => const UserMainScreen(), binding: UserBindings());
  //           Get.offAll(() => const DashboardScreen(), binding: UserBindings());

  //           await Fluttertoast.showToast(msg: "Successfully Logged In");
  //         } else if (mapData['role'] == 'Car Mechanic') {
  //           Get.offAll(() => const CarMechMainScreen(),
  //               binding: MechanicBindings());
  //           await Fluttertoast.showToast(msg: "Successfully Logged In");
  //         } else if (mapData['role'] == 'Car Tow') {
  //           Get.offAll(() => const CarTowMainScreen(),
  //               binding: CarTowBindings());
  //           await Fluttertoast.showToast(msg: "Successfully Logged In");
  //         }
  //       } else {
  //         // return const VerificationScreen();
  //         _auth.currentUser!.sendEmailVerification();
  //       }
  //     }
  //   });
  // }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // veryfyingUser();
    timer = Timer.periodic(const Duration(seconds: 5), (timer) async {
      FirebaseAuth.instance.currentUser?.reload();
      if (FirebaseAuth.instance.currentUser!.emailVerified == true) {
        timer.cancel();
        var docData = await FirebaseFirestore.instance
            .collection('users')
            .doc(FirebaseAuth.instance.currentUser!.uid)
            .get();
        var mapData = docData.data() as Map<String, dynamic>;
        if (mapData['role'] == 'User') {
          // Get.offAll(() => const UserMainScreen(), binding: UserBindings());
          Get.offAll(() => const DashboardScreen(), binding: UserBindings());

          await Fluttertoast.showToast(msg: "Successfully Logged In");
        } else if (mapData['role'] == 'Car Mechanic') {
          Get.offAll(() => const CarMechMainScreen(),
              binding: MechanicBindings());
          await Fluttertoast.showToast(msg: "Successfully Logged In");
        } else if (mapData['role'] == 'Car Tow') {
          Get.offAll(() => const CarTowMainScreen(), binding: CarTowBindings());
          await Fluttertoast.showToast(msg: "Successfully Logged In");
        }
      } else if (FirebaseAuth.instance.currentUser!.emailVerified == false) {
        _auth.currentUser!.sendEmailVerification();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text('We have sent an email for verification.'),
            // TextButton(
            //     onPressed: () async {
            //       _auth.sendEmailVerificationLink();
            //     },
            //     child: const Text('Resend Email'))
          ],
        ),
      ),
    );
  }
}
