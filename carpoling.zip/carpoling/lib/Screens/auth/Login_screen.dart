import 'package:carpoling_1/Screens/auth/verification_screen.dart';
import 'package:carpoling_1/Screens/car_mechanic_panel/mech_main_screen.dart';
import 'package:carpoling_1/Screens/car_tow_panel/cartow_main_screen.dart';
import 'package:carpoling_1/Screens/user_panel/dashboard/dashboard.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/user_main_screen.dart';
import 'package:carpoling_1/bindings/bindings.dart';
import 'package:carpoling_1/widgets/dashboard_card.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

import '../../Global/global.dart';
import 'Registrartion_screen.dart';
import 'forgot_password_screen.dart';
import '../driver_panel/driver_main_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final emailTextEditingController = TextEditingController();
  final passwordTextEditingController = TextEditingController();
  bool _passwordvisible = false;

  //declare a GlobalKey
  final _formkey = GlobalKey<FormState>();
  void _submit() async {
    // validate all the form Fields
    if (_formkey.currentState!.validate()) {
      await firebaseAuth
          .signInWithEmailAndPassword(
              email: emailTextEditingController.text.trim(),
              password: passwordTextEditingController.text.trim())
          .then((auth) async {
        currentUser = auth.user;
        var docData = await FirebaseFirestore.instance
            .collection('users')
            .doc(auth.user!.uid)
            .get();
        var mapData = docData.data() as Map<String, dynamic>;

        // if (currentUser!.emailVerified) {
        if (mapData['role'] == 'User') {
          // Get.offAll(() => const UserMainScreen(), binding: UserBindings());
          Get.offAll(() => const DashboardScreen(), binding: UserBindings());
          await Fluttertoast.showToast(msg: "Successfully Logged In");
        } else if (mapData['role'] == 'Driver') {
          Get.offAll(() => const DriverMainScreen(), binding: DriverBindings());
        } else if (mapData['role'] == 'Car Mechanic') {
          Get.offAll(() => const CarMechMainScreen(),
              binding: MechanicBindings());
          await Fluttertoast.showToast(msg: "Successfully Logged In");
        } else if (mapData['role'] == 'Car Tow') {
          Get.offAll(() => const CarTowMainScreen(), binding: CarTowBindings());
          await Fluttertoast.showToast(msg: "Successfully Logged In");
        }
        // } else {
        //   Get.to(() => const VerificationScreen());
        // }

        // Navigator.push(context,
        //     MaterialPageRoute(builder: (c) => const DriverMainScreen()));
      }).catchError((errorMessage) {
        Fluttertoast.showToast(msg: "Error occured: \n $errorMessage");
      });
    } else {
      Fluttertoast.showToast(msg: "Not all field are valid");
    }
  }

  @override
  Widget build(BuildContext context) {
    bool darktheme =
        MediaQuery.of(context).platformBrightness == Brightness.dark;
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        body: ListView(
          padding: const EdgeInsets.all(0),
          children: [
            Column(
              children: [
                Image.asset(
                    darktheme ? 'images/city_dark.jpg' : 'images/city.jpg'),
                const SizedBox(
                  height: 20,
                ),
                Text(
                  'Login',
                  style: TextStyle(
                    color: darktheme ? Colors.amber.shade400 : Colors.blue,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(
                      15, 20, 15, 50), //Left Top right Bootm
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Form(
                        key: _formkey,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            TextFormField(
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(100)
                              ],
                              decoration: InputDecoration(
                                hintText: "Email",
                                hintStyle: const TextStyle(
                                  color: Colors.grey,
                                ),
                                filled: true,
                                fillColor: darktheme
                                    ? Colors.black45
                                    : Colors.grey.shade200,
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(40),
                                    borderSide: const BorderSide(
                                      width: 0,
                                      style: BorderStyle.none,
                                    )),
                                prefixIcon: Icon(
                                  Icons.person,
                                  color: darktheme
                                      ? Colors.amber.shade400
                                      : Colors.grey,
                                ),
                              ),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (text) {
                                if (text == null || text.isEmpty) {
                                  return 'Email can not be empty';
                                }
                                if (text.length < 2) {
                                  return "Please enter a valid Email";
                                }
                                if (EmailValidator.validate(text) == true) {
                                  return null;
                                }
                                if (text.length > 100) {
                                  return "Email can not be more then 100 ";
                                }
                                return null;
                              },
                              onChanged: (text) => setState(() {
                                emailTextEditingController.text =
                                    text; //write text
                              }),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            TextFormField(
                              obscureText: !_passwordvisible,
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(50)
                              ],
                              decoration: InputDecoration(
                                  hintText: "Password",
                                  hintStyle: const TextStyle(
                                    color: Colors.grey,
                                  ),
                                  filled: true,
                                  fillColor: darktheme
                                      ? Colors.black45
                                      : Colors.grey.shade200,
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(40),
                                      borderSide: const BorderSide(
                                        width: 0,
                                        style: BorderStyle.none,
                                      )),
                                  prefixIcon: Icon(
                                    Icons.person,
                                    color: darktheme
                                        ? Colors.amber.shade400
                                        : Colors.grey,
                                  ),
                                  suffixIcon: IconButton(
                                      icon: Icon(
                                        _passwordvisible
                                            ? Icons.visibility
                                            : Icons.visibility_off,
                                        color: darktheme
                                            ? Colors.amber.shade400
                                            : Colors.grey,
                                      ),
                                      onPressed: () {
                                        //Update the state
                                        setState(() {
                                          _passwordvisible = !_passwordvisible;
                                        });
                                      })),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (text) {
                                if (text == null || text.isEmpty) {
                                  return 'Password can not be empty';
                                }
                                if (text.length < 2) {
                                  return "Please enter a valid Password";
                                }
                                if (text.length > 50) {
                                  return "Password can not be more then 50 ";
                                }
                                return null;
                              },
                              onChanged: (text) => setState(() {
                                passwordTextEditingController.text = text;
                              }),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    foregroundColor:
                                        darktheme ? Colors.black : Colors.white,
                                    backgroundColor: darktheme
                                        ? Colors.amber.shade400
                                        : Colors.blue,
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(32),
                                    ),
                                    minimumSize:
                                        const Size(double.infinity, 50)),
                                onPressed: () {
                                  _submit();
                                },
                                child: const Text(
                                  'Login',
                                  style: TextStyle(
                                    fontSize: 20,
                                  ),
                                )),
                            const SizedBox(
                              height: 20,
                            ),
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (c) =>
                                            const ForgotPasswordScreen()));
                              },
                              child: Text(
                                'Forgot Password',
                                style: TextStyle(
                                  color: darktheme
                                      ? Colors.amber.shade400
                                      : Colors.blue,
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text(
                                  "Does not have a account?",
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 15,
                                  ),
                                ),
                                const SizedBox(
                                  width: 5,
                                ),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (c) =>
                                                const RegisterScreen()));
                                  },
                                  child: Text(
                                    "Register",
                                    style: TextStyle(
                                      fontSize: 15,
                                      color: darktheme
                                          ? Colors.amber.shade400
                                          : Colors.blue,
                                    ),
                                  ),
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
