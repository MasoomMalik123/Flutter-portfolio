import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  //send email verification
  Future<void> sendEmailVerficationLink() async {
    try {
      await FirebaseAuth.instance.currentUser!.sendEmailVerification();
    } catch (e) {
      print(e.toString());
    }
  }
}
