// import 'package:carpoling_1/Screens/auth/Login_screen.dart';
// import 'package:carpoling_1/Screens/auth/verification_screen.dart';
// import 'package:carpoling_1/Screens/driver_panel/driver_main_screen.dart';
// import 'package:carpoling_1/Screens/user_panel/ride_share/user_main_screen.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';

// class Wrapper extends StatefulWidget {
//   const Wrapper({super.key});

//   @override
//   State<Wrapper> createState() => _WrapperState();
// }

// class _WrapperState extends State<Wrapper> {
//   String userRole = '';
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     getCurentUserRole();
//   }

//   getCurentUserRole() async {
//     var user = await FirebaseFirestore.instance
//         .collection('users')
//         .doc(FirebaseAuth.instance.currentUser!.uid)
//         .get();
//     if (user.exists) {
//       var map = user.data() as Map<String, dynamic>;
//       userRole = map['role'];
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body:
      
//        StreamBuilder<User?>(
//         stream: FirebaseAuth.instance.authStateChanges(),
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return const Center(
//               child: CircularProgressIndicator(),
//             );
//           } else if (snapshot.hasError) {
//             return const Center(
//               child: Text('Error'),
//             );
//           } else {
//             if (snapshot.data == null) {
//               return LoginScreen();
//             } else {
//               if (snapshot.data?.emailVerified == true) {
//                 return const HomeScreen();
//               } else {
//                 return const VerificationScreen();
//               }
//             }
//           }
//         },
//       ),
//       //  StreamBuilder(
//       //     stream: FirebaseAuth.instance.authStateChanges(),
//       //     builder: (context, snapshot) {
//       //       if (snapshot.connectionState == ConnectionState.waiting) {
//       //         return const Center(
//       //           child: CircularProgressIndicator(),
//       //         );
//       //       } else if (snapshot.hasError) {
//       //         return const Center(
//       //           child: Text('Error'),
//       //         );
//       //       } else {
//       //         if (snapshot.data == null) {
//       //           return const LoginScreen();
//       //         } else {
//       //           if (snapshot.data!.emailVerified) {
//       //             if (userRole == 'User') {
//       //               return const UserMainScreen();
//       //             } else {
//       //               return const DriverMainScreen();
//       //             }
//       //           } else {
//       //             return const VerificationScreen();
//       //           }
//       //         }
//       //       }
//       //     }),
//     );
//   }
// }
