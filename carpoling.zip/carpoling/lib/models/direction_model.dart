class DirectionModel {
  final List<GeocodedWaypoint> geocodedWaypoints;
  final List<Route> routes;
  final String status;

  DirectionModel({
    required this.geocodedWaypoints,
    required this.routes,
    required this.status,
  });

  factory DirectionModel.fromJson(Map<String, dynamic> json) {
    return DirectionModel(
      geocodedWaypoints: List<GeocodedWaypoint>.from(
          json['geocoded_waypoints'].map((x) => GeocodedWaypoint.fromJson(x))),
      routes: List<Route>.from(json['routes'].map((x) => Route.fromJson(x))),
      status: json['status'],
    );
  }
}

class GeocodedWaypoint {
  final String geocoderStatus;
  final String placeId;
  final List<String> types;

  GeocodedWaypoint({
    required this.geocoderStatus,
    required this.placeId,
    required this.types,
  });

  factory GeocodedWaypoint.fromJson(Map<String, dynamic> json) {
    return GeocodedWaypoint(
      geocoderStatus: json['geocoder_status'],
      placeId: json['place_id'],
      types: List<String>.from(json['types'].map((x) => x)),
    );
  }
}

class Route {
  final Bounds bounds;
  final String copyrights;
  final List<Leg> legs;
  final Polyline overviewPolyline;
  final String summary;
  final List<dynamic> warnings;
  final List<dynamic> waypointOrder;

  Route({
    required this.bounds,
    required this.copyrights,
    required this.legs,
    required this.overviewPolyline,
    required this.summary,
    required this.warnings,
    required this.waypointOrder,
  });

  factory Route.fromJson(Map<String, dynamic> json) {
    return Route(
      bounds: Bounds.fromJson(json['bounds']),
      copyrights: json['copyrights'],
      legs: List<Leg>.from(json['legs'].map((x) => Leg.fromJson(x))),
      overviewPolyline: Polyline.fromJson(json['overview_polyline']),
      summary: json['summary'],
      warnings: List<dynamic>.from(json['warnings'].map((x) => x)),
      waypointOrder: List<dynamic>.from(json['waypoint_order'].map((x) => x)),
    );
  }
}

class Bounds {
  final Northeast northeast;
  final Northeast southwest;

  Bounds({
    required this.northeast,
    required this.southwest,
  });

  factory Bounds.fromJson(Map<String, dynamic> json) {
    return Bounds(
      northeast: Northeast.fromJson(json['northeast']),
      southwest: Northeast.fromJson(json['southwest']),
    );
  }
}

class Northeast {
  final double lat;
  final double lng;

  Northeast({
    required this.lat,
    required this.lng,
  });

  factory Northeast.fromJson(Map<String, dynamic> json) {
    return Northeast(
      lat: json['lat'],
      lng: json['lng'],
    );
  }
}

class Leg {
  final Distance distance;
  final Distance duration;
  final String endAddress;
  final Northeast endLocation;
  final String startAddress;
  final Northeast startLocation;
  final List<Step> steps;
  final List<dynamic> trafficSpeedEntry;
  final List<dynamic> viaWaypoint;

  Leg({
    required this.distance,
    required this.duration,
    required this.endAddress,
    required this.endLocation,
    required this.startAddress,
    required this.startLocation,
    required this.steps,
    required this.trafficSpeedEntry,
    required this.viaWaypoint,
  });

  factory Leg.fromJson(Map<String, dynamic> json) {
    return Leg(
      distance: Distance.fromJson(json['distance']),
      duration: Distance.fromJson(json['duration']),
      endAddress: json['end_address'],
      endLocation: Northeast.fromJson(json['end_location']),
      startAddress: json['start_address'],
      startLocation: Northeast.fromJson(json['start_location']),
      steps: List<Step>.from(json['steps'].map((x) => Step.fromJson(x))),
      trafficSpeedEntry:
          List<dynamic>.from(json['traffic_speed_entry'].map((x) => x)),
      viaWaypoint: List<dynamic>.from(json['via_waypoint'].map((x) => x)),
    );
  }
}

class Distance {
  final String text;
  final int value;

  Distance({
    required this.text,
    required this.value,
  });

  factory Distance.fromJson(Map<String, dynamic> json) {
    return Distance(
      text: json['text'],
      value: json['value'],
    );
  }
}

class Step {
  final Distance distance;
  final Distance duration;
  final Northeast endLocation;
  final String htmlInstructions;
  final Polyline polyline;
  final Northeast startLocation;
  final TravelMode travelMode;
  final String? maneuver;

  Step({
    required this.distance,
    required this.duration,
    required this.endLocation,
    required this.htmlInstructions,
    required this.polyline,
    required this.startLocation,
    required this.travelMode,
    this.maneuver,
  });

  factory Step.fromJson(Map<String, dynamic> json) {
    return Step(
      distance: Distance.fromJson(json['distance']),
      duration: Distance.fromJson(json['duration']),
      endLocation: Northeast.fromJson(json['end_location']),
      htmlInstructions: json['html_instructions'],
      polyline: Polyline.fromJson(json['polyline']),
      startLocation: Northeast.fromJson(json['start_location']),
      travelMode:
          travelModeValues.map[json['travel_mode']] ?? TravelMode.DRIVING,
      maneuver: json['maneuver'] ?? "",
    );
  }
}

class Polyline {
  final String points;

  Polyline({
    required this.points,
  });

  factory Polyline.fromJson(Map<String, dynamic> json) {
    return Polyline(
      points: json['points'],
    );
  }
}

enum TravelMode {
  DRIVING,
}

final travelModeValues = EnumValues({'DRIVING': TravelMode.DRIVING});

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String>? reverseMap;

  EnumValues(this.map);

  Map<T, String>? get reverse {
    reverseMap ??= map.map((k, v) => MapEntry(v, k));
    return reverseMap;
  }
}
