import 'package:carpoling_1/model/user_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class UserProfileController extends GetxController {
  Rx<UserModel> userModel = UserModel(
    id: '',
    name: '',
    email: '',
    phone: '',
    role: '',
  ).obs;

  getUserProfile() async {
    var docData = await FirebaseFirestore.instance
        .collection('users')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .get();
    if (docData.exists) {
      var mapData = docData.data() as Map<String, dynamic>;
      UserModel model = UserModel.fromJson(mapData);
      userModel.value = model;
      update();
    }
  }

  updateUserModel(UserModel model) {
    userModel.value = model;
    update();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getUserProfile();
  }
}
