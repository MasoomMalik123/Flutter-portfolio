import 'dart:convert';

import 'package:carpoling_1/Global/map_key.dart';
import 'package:carpoling_1/model/ride_model.dart';
import 'package:carpoling_1/model/user_model.dart';
import 'package:carpoling_1/models/direction_model.dart';
import 'package:carpoling_1/utils/utils.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart' as pp;
import 'package:http/http.dart' as http;

class DriverController extends GetxController {
  RxString driverName = ''.obs;
  RxString driverEmail = ''.obs;
  RxString driverPhone = ''.obs;
  GoogleMapController? mapController;

  RxBool isTapedOnShowRoute = false.obs;
  CameraPosition? currentCamPosition;
  RxList<Marker> allMarkers = <Marker>[].obs;

  Rx<UserModel> driverModel =
      UserModel(id: '', name: '', email: '', phone: '', role: '').obs;

  RxList<Ride> currentUserDriverRides = <Ride>[].obs;
  final RxList<LatLng> polylineCordinates = <LatLng>[].obs;
  final Rx<DirectionModel?> currentdirectionModel = Rx<DirectionModel?>(null);

  getDriverInfo() async {
    var doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .get();

    if (doc.exists) {
      var data = doc.data() as Map<String, dynamic>;
      driverModel.value = UserModel.fromJson(data);
      driverEmail.value = data['email'];
      driverName.value = data['name'];
      driverPhone.value = data['phone'];
    }
  }


   updateDriverModel(UserModel model) {
    driverModel.value = model;
    update();
  }

  Rx<DateTime?> selectedDate = Rx<DateTime?>(null);
  Rx<TimeOfDay?> selectedTime = Rx<TimeOfDay?>(null);

  Future<void> pickDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedDate.value ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (pickedDate != null && pickedDate != selectedDate.value) {
      selectedDate.value = pickedDate;
      update();
    }
  }

  Future<void> pickTime(BuildContext context) async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: selectedTime.value ?? TimeOfDay.now(),
    );
    if (pickedTime != null && pickedTime != selectedTime.value) {
      selectedTime.value = pickedTime;
      update();
    }
  }

  getDriverRides() async {
    currentUserDriverRides.clear();
    var rideDocs = await FirebaseFirestore.instance
        .collection('rides')
        .where('driverId', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .get();
    for (var rideDoc in rideDocs.docs) {
      var mapData = rideDoc.data();
      var modelRide = Ride.fromJson(mapData);
      currentUserDriverRides.add(modelRide);
      update();
    }
  }

  // method to get polyline from flutter polyline package
  getPolyLine(LatLng currentLatlng, LatLng destinationLatlng) async {
    pp.PolylinePoints polylinePoints = pp.PolylinePoints();
    pp.PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        mapKey,
        pp.PointLatLng(double.parse(currentLatlng.latitude.toString()),
            double.parse(currentLatlng.longitude.toString())),
        pp.PointLatLng(double.parse(destinationLatlng.latitude.toString()),
            double.parse(destinationLatlng.longitude.toString())),
        travelMode: pp.TravelMode.driving);
    if (result.points.isNotEmpty) {
      polylineCordinates.clear();

      for (var point in result.points) {
        polylineCordinates.add(LatLng(point.latitude, point.longitude));
      }
    }
    update();
  }

  // get polyline through direction api
  void getPolylinePoints(DirectionModel directionModel) {
    PolylinePoints polylinePoints = PolylinePoints();
    String points = directionModel.routes.first.overviewPolyline.points;

    List<PointLatLng> decodedPointLatLng =
        polylinePoints.decodePolyline(points);
    List<LatLng> listLatLng = decodedPointLatLng
        .map((point) => LatLng(point.latitude, point.longitude))
        .toList();

    polylineCordinates.value = listLatLng;

    update();
    // return ListLatLng;
  }

  //getting data from direction api
  Future<void> getDirectionData(double originLat, double originLong,
      double destLat, double destLong) async {
    const apiKey = 'AIzaSyCNwTZRqJ6qmu_3FLHLvl9mKKAooHRUP4U';
    final apiUrl =
        "https://maps.googleapis.com/maps/api/directions/json?origin=$originLat,$originLong&destination=$destLat,$destLong&key=$apiKey";

    final response = await http.get(Uri.parse(apiUrl));
    if (response.statusCode == 200) {
      // final data = json.decode(response.body);
      // print('Direction data');
      // print(data);
      // currentdirectionModel.value = DirectionModel.fromJson(data);

      // speakIfTurn(
      //   directionModel: currentdirectionModel.value,
      // );

      print('Direction data 2');
      try {
        final response = await http.get(Uri.parse(apiUrl));

        if (response.statusCode == 200) {
          final data = json.decode(response.body);

          if (data["status"] == "ZERO_RESULTS") {
            // Handle case where no results are found
            // _haveLocationIcon.value = false;
            print('No Route found');
            showToast('No Route found');
            return;
          }

          currentdirectionModel.value = DirectionModel.fromJson(data);
          // _haveLocationIcon.value = true;

          getPolylinePoints(currentdirectionModel.value!);
          print('Direction data 2');
        } else {
          // Handle non-200 status code
          print('Error: ${response.statusCode} - ${response.reasonPhrase}');
        }
      } catch (e) {
        // Handle general exceptions
        print('Error fetching direction data: $e');
      }
    }
    update();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getDriverInfo();
    getDriverRides();
  }
}
