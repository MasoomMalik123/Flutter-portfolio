import 'dart:convert';

import 'package:carpoling_1/Global/map_key.dart';
import 'package:carpoling_1/Screens/user_panel/ride_share/show_all_rides_for_user.dart';
import 'package:carpoling_1/model/ride_model.dart';
import 'package:carpoling_1/models/direction_model.dart';
import 'package:carpoling_1/utils/utils.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart' as pp;
import 'package:http/http.dart' as http;

class UserController extends GetxController {
  RxList<Ride> ridesForUser = <Ride>[].obs;
  RxList<Ride> userBookedRide = <Ride>[].obs;

  GoogleMapController? mapController;
  CameraPosition? currentCamPosition;
  RxList<Marker> allMarkers = <Marker>[].obs;
  RxBool isTapedOnShowRoute = false.obs;

  final RxList<LatLng> polylineCordinates = <LatLng>[].obs;
  final Rx<DirectionModel?> currentdirectionModel = Rx<DirectionModel?>(null);

  getAllRidesAvailableForUser(
      {required String fromLocation,
      required String toLocation,
      required BuildContext context}) async {
    ridesForUser.clear();
    var rideDocs = await FirebaseFirestore.instance
        .collection('rides')
        .where(
          'driverRideStartLocation',
          isEqualTo: fromLocation,
        )
        .where(
          'driverRideEndLocation',
          isEqualTo: toLocation,
        )
        .get();
    if (rideDocs.docs.isNotEmpty) {
      for (var ride in rideDocs.docs) {
        var mapData = ride.data();
        var rideModel = Ride.fromJson(mapData);
        ridesForUser.add(rideModel);
        update();
      }
      Get.to(() => ShowAllRidesForUser());
    } else {
      showToast('No Ride Avaiable');
    }
  }

  getAllBookedRidesForUser() async {
    userBookedRide.clear();
    var docList = await FirebaseFirestore.instance
        .collection('rides')
        .where('bookedRides',
            arrayContains: FirebaseAuth.instance.currentUser!.uid)
        .get();

    if (docList.docs.isNotEmpty) {
      for (var docData in docList.docs) {
        Map<String, dynamic> mapData = docData.data();
        Ride rideModel = Ride.fromJson(mapData);
        userBookedRide.add(rideModel);
        update();
      }
    }
  }

  // method to get polyline from flutter polyline package
  getPolyLine(LatLng currentLatlng, LatLng destinationLatlng) async {
    pp.PolylinePoints polylinePoints = pp.PolylinePoints();
    pp.PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        mapKey,
        pp.PointLatLng(double.parse(currentLatlng.latitude.toString()),
            double.parse(currentLatlng.longitude.toString())),
        pp.PointLatLng(double.parse(destinationLatlng.latitude.toString()),
            double.parse(destinationLatlng.longitude.toString())),
        travelMode: pp.TravelMode.driving);
    if (result.points.isNotEmpty) {
      polylineCordinates.clear();

      for (var point in result.points) {
        polylineCordinates.add(LatLng(point.latitude, point.longitude));
      }
    }
    update();
  }

  // get polyline through direction api
  void getPolylinePoints(DirectionModel directionModel) {
    PolylinePoints polylinePoints = PolylinePoints();
    String points = directionModel.routes.first.overviewPolyline.points;

    List<PointLatLng> decodedPointLatLng =
        polylinePoints.decodePolyline(points);
    List<LatLng> listLatLng = decodedPointLatLng
        .map((point) => LatLng(point.latitude, point.longitude))
        .toList();

    polylineCordinates.value = listLatLng;

    update();
    // return ListLatLng;
  }

  //getting data from direction api
  Future<void> getDirectionData(double originLat, double originLong,
      double destLat, double destLong) async {
    const apiKey = 'AIzaSyCNwTZRqJ6qmu_3FLHLvl9mKKAooHRUP4U';
    final apiUrl =
        "https://maps.googleapis.com/maps/api/directions/json?origin=$originLat,$originLong&destination=$destLat,$destLong&key=$apiKey";

    final response = await http.get(Uri.parse(apiUrl));
    if (response.statusCode == 200) {
      // final data = json.decode(response.body);
      // print('Direction data');
      // print(data);
      // currentdirectionModel.value = DirectionModel.fromJson(data);

      // speakIfTurn(
      //   directionModel: currentdirectionModel.value,
      // );

      print('Direction data 2');
      try {
        final response = await http.get(Uri.parse(apiUrl));

        if (response.statusCode == 200) {
          final data = json.decode(response.body);

          if (data["status"] == "ZERO_RESULTS") {
            // Handle case where no results are found
            // _haveLocationIcon.value = false;
            print('No Route found');
            showToast('No Route found');
            return;
          }

          currentdirectionModel.value = DirectionModel.fromJson(data);
          // _haveLocationIcon.value = true;

          getPolylinePoints(currentdirectionModel.value!);
          print('Direction data 2');
        } else {
          // Handle non-200 status code
          print('Error: ${response.statusCode} - ${response.reasonPhrase}');
        }
      } catch (e) {
        // Handle general exceptions
        print('Error fetching direction data: $e');
      }
    }
    update();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getAllBookedRidesForUser();
  }
}
