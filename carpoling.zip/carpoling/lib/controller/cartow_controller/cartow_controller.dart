import 'dart:async';
import 'package:carpoling_1/Screens/user_panel/car_mechanic/user_mechanic_booking.dart';
import 'package:carpoling_1/model/car_mech_booking_model.dart';
import 'package:carpoling_1/model/car_tow_booking_model.dart';
import 'package:carpoling_1/utils/utils.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geoflutterfire_plus/geoflutterfire_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class CarTowController extends GetxController {
  RxList<CarTowBookingModel> carTowBookings =
      <CarTowBookingModel>[].obs;
  RxList<Marker> markers = <Marker>[].obs;
  GoogleMapController? mapController;
  BitmapDescriptor? carTowMarker;
  BitmapDescriptor? carTowSelfMarker;

  Rx<LatLng> userCurrentLatLng = const LatLng(0, 0).obs;
  final Completer<GoogleMapController> _controller = Completer();

  // get all cartows within query of 50 km radius
  getCarTowsStreams(LatLng userLatLng) {
    // user current location
    GeoPoint userCurrentLocation =
        GeoPoint(userLatLng.latitude, userLatLng.longitude);

// Center of the geo query.
    final GeoFirePoint center = GeoFirePoint(userCurrentLocation);

// Detection range from the center point.
    const double radiusInKm = 50;

// Field name of Cloud Firestore documents where the geohash is saved.
    const String field = 'carTowMap';
    // Function to get GeoPoint instance from Cloud Firestore document data.
    GeoPoint geopointFrom(Map<String, dynamic> data) =>
        (data['carTowMap'] as Map<String, dynamic>)['geopoint']
            as GeoPoint;
    // Streamed typed document snapshots of geo query under given conditions.
    Stream<List<DocumentSnapshot>> stream =
        GeoCollectionReference(FirebaseFirestore.instance.collection('users'))
            .subscribeWithin(
      center: center,
      radiusInKm: radiusInKm,
      field: field,
      geopointFrom: geopointFrom,
    );

    stream.listen((event) {
      for (var element in event) {
        var doc = element.data() as Map<String, dynamic>;
        GeoPoint latLng = doc['carTowMap']['geopoint'];
        String carTowName = doc['name'];
        String carTowEmail = doc['email'];
        String carTowNum = doc['phone'];
        String carTowId = doc['id'];

        Marker marker = Marker(
          markerId: MarkerId(carTowName),
          position: LatLng(latLng.latitude, latLng.longitude),
          infoWindow: InfoWindow(title: carTowName),
          icon: carTowId == FirebaseAuth.instance.currentUser!.uid
              ? carTowSelfMarker ?? BitmapDescriptor.defaultMarker
              : carTowMarker ?? BitmapDescriptor.defaultMarker,
          onTap: () {
            showDialog(
              context: Get.context!,
              builder: (BuildContext context) {
                return AlertDialog(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  title: Text(
                    carTowName,
                    style: const TextStyle(
                      color: Colors.blueAccent,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Row(
                        children: [
                          const Icon(Icons.email, color: Colors.blueAccent),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              carTowEmail,
                              style: const TextStyle(
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const Icon(Icons.phone, color: Colors.blueAccent),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              carTowNum,
                              style: const TextStyle(
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  actions: <Widget>[
                    // TextButton(
                    //   child: const Text(
                    //     'Book Now',
                    //     style: TextStyle(color: Colors.red),
                    //   ),
                    //   onPressed: () {
                    //     Get.to(() => CarMechanicBookingForm(
                    //           carMechanicId: carMechanicId,
                    //           carMechanicEmail: carMechanicEmail,
                    //           carMechanicName: carMechanicName,
                    //           carMechanicNum: carMechanicNum,
                    //         ));
                    //   },
                    // ),
                    TextButton(
                      child: const Text(
                        'Close',
                        style: TextStyle(color: Colors.red),
                      ),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                );
              },
            );
            // showDialog(
            //   context: Get.context!,
            //   builder: (BuildContext context) {
            //     return AlertDialog(
            //       title: Text(carTowName),
            //       content: Column(
            //         mainAxisSize: MainAxisSize.min,
            //         children: <Widget>[
            //           Text('Email: $carTowEmail'),
            //           Text('Phone: $carTowNum'),
            //         ],
            //       ),
            //       actions: <Widget>[
            //         TextButton(
            //           child: const Text('Close'),
            //           onPressed: () {
            //             Navigator.of(context).pop();
            //           },
            //         ),
            //       ],
            //     );
            //   },
            // );
          },
          // icon: BitmapDescriptor.defaultMarker,
        );
        markers.add(marker);
        update();
      }
    });
  }

  getCurrentPostionStream() {
    const LocationSettings locationSettings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 20,
    );
    StreamSubscription<Position> positionStream = Geolocator.getPositionStream(
      locationSettings: locationSettings,
    ).listen((Position position) {
      var latLng = LatLng(position.latitude, position.longitude);
      userCurrentLatLng.value = latLng;
      update();
      print(position == null
          ? 'Unknown'
          : '${position.latitude.toString()}, ${position.longitude.toString()}');
    });
  }

  getCurrentLatLng(double lat, double long) {
    userCurrentLatLng.value = LatLng(lat, long);
    print('USer current Loc : ${userCurrentLatLng.value}');
    update();
  }

  void initMap() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    Position initialLocation = await Geolocator.getCurrentPosition();
    print("This is initial Position $initialLocation");
    getCurrentLatLng(initialLocation.latitude, initialLocation.longitude);
    GoogleMapController googleMapController = await _controller.future;
    googleMapController.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          zoom: 14,
          target: LatLng(initialLocation.latitude, initialLocation.longitude),
          // LatLng(-33.822810000, 151.048750000),
        ),
      ),
    );
  }

  showAllCarTowBookings() async {
    var allDocs = await FirebaseFirestore.instance
        .collection('car_tow_bookings')
        .where('carTowId',
            isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .get();
    if (allDocs.docs.isNotEmpty) {
      for (var doc in allDocs.docs) {
        carTowBookings.add(CarTowBookingModel.fromFirestore(doc));
        update();
      }
    }
  }

  updateIndexOfModel(CarTowBookingModel model, int index, String doc,
      String status) async {
    carTowBookings[index] = model;
    await FirebaseFirestore.instance
        .collection('car_tow_bookings')
        .doc(doc)
        .update({'status': status});
    update();
  }

  @override
  void onInit() async {
    // TODO: implement onInit
    super.onInit();
    initMap();

    carTowMarker =
        await createResizedMarkerImageFromAsset('images/cartow.png', 100, 100);
    carTowSelfMarker = await createResizedMarkerImageFromAsset(
        'images/cartow_self.png', 100, 100);
    getCurrentPostionStream();
    'This is the user current location :  ${userCurrentLatLng.value}';
    update();
    showAllCarTowBookings();

    // getAllTrucks();
  }
}
