import 'package:carpoling_1/model/car_mech_model.dart';
import 'package:carpoling_1/model/car_tow_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geoflutterfire_plus/geoflutterfire_plus.dart';

// doc to create car tow doc
void createCarTowGeoDocument({
  required double latitude,
  required double longitude,
  required String name,
  required String email,
  required String num,
  required String docId,
}) async {
  // Initialize GeoFlutterFire
  final geo = GeoFirePoint(GeoPoint(latitude, longitude));

  // Create a GeoFirePoint

  // Get the data map containing GeoPoint and geohash
  final Map<String, dynamic> data = geo.data;

  // Reference to Firestore
  final firestore = FirebaseFirestore.instance;
  Map<String, dynamic> mapData = {
    'name': name,
    'email': email,
    'num': num,
    'carTowMap': data,
    'docId': docId,
  };

  // Add data to Firestore
  await firestore.collection('car_tow_users').doc(docId).set(mapData);
  print('Document $docId created with data: $mapData');
}

void createMultipleGeoDocumentsForCarTows(List<CarTowModel> models) {
  for (var model in models) {
    final latitude = model.latitude;
    final longitude = model.longitude;
    final name = model.name;
    final email = model.email;
    final num = model.num;

    // final docId = location['docId'];
    String id = DateTime.now().millisecondsSinceEpoch.toString();

    createCarTowGeoDocument(
      latitude: latitude,
      longitude: longitude,
      name: name,
      email: email,
      num: num,
      docId: id,
    );
  }
}

List<CarTowModel> listOfCarTowsUsers = [
  CarTowModel(
      latitude: 33.57116015340302,
      longitude: 73.03497295754401,
      email: 'Yasir@gmail.com',
      name: 'Yasir',
      num: '+921505565632'),
  CarTowModel(
      latitude: 33.557571404962715,
      longitude: 73.05411320170964,
      email: 'ali@gmail.com',
      name: 'Ali',
      num: '+921505565632'),
  CarTowModel(
      latitude: 33.604354189796965,
      longitude: 73.04866295284756,
      email: 'ahmad@gmail.com',
      name: 'Ahmad',
      num: '+921505565632'),
  CarTowModel(
      latitude: 33.644408640532994,
      longitude: 73.01649793320863,
      email: 'iftikhar@gmail.com',
      name: 'Iftikhar',
      num: '+921505565632'),
  CarTowModel(
      latitude: 33.64633785998172,
      longitude: 73.00568326669713,
      email: 'hussain@gmail.com',
      name: 'Hussain',
      num: '+921505565632'),
  CarTowModel(
      latitude: 33.61221288157151,
      longitude: 73.12146886683813,
      email: 'raza@gmail.com',
      name: 'Raza',
      num: '+921505565632'),
  CarTowModel(
      latitude: 33.59338483805704,
      longitude: 73.01513477146456,
      email: 'husnain@gmail.com',
      name: 'Husnain',
      num: '+921505565632'),
  CarTowModel(
      latitude: 33.56435528846086,
      longitude: 73.02348111660535,
      email: 'hammad@gmail.com',
      name: 'Hammad',
      num: '+921505565632'),
  CarTowModel(
      latitude: 33.57467139443752,
      longitude: 73.09407685918198,
      email: 'ilyas@gmail.com',
      name: 'Ilyas',
      num: '+921505565632'),
  CarTowModel(
      latitude: 33.588212764323345,
      longitude: 73.08144901896179,
      email: 'badar@gmail.com',
      name: 'Badar',
      num: '+921505565632'),
];

/////////////////// doc to create car mech doc ///////////////////
void createCarMechGeoDocument({
  required double latitude,
  required double longitude,
  required String name,
  required String email,
  required String num,
  required String docId,
}) async {
  // Initialize GeoFlutterFire
  final geo = GeoFirePoint(GeoPoint(latitude, longitude));

  // Create a GeoFirePoint

  // Get the data map containing GeoPoint and geohash
  final Map<String, dynamic> data = geo.data;

  // Reference to Firestore
  final firestore = FirebaseFirestore.instance;
  Map<String, dynamic> mapData = {
    'carMechanicName': name,
    'carMechanicEmail': email,
    'carMechanicNum': num,
    'carMechanicMap': data,
    'docId': docId,
  };

  // Add data to Firestore
  await firestore.collection('car_mechanic_users').doc(docId).set(mapData);
  print('Document $docId created with data: $mapData');
}

void createMultipleGeoDocumentsForCarMechanics(List<CarMechModel> models) {
  for (var model in models) {
    final latitude = model.latitude;
    final longitude = model.longitude;
    final name = model.name;
    final email = model.email;
    final num = model.num;

    // final docId = location['docId'];
    String id = DateTime.now().millisecondsSinceEpoch.toString();

    createCarMechGeoDocument(
      latitude: latitude,
      longitude: longitude,
      name: name,
      email: email,
      num: num,
      docId: id,
    );
  }
}

List<CarMechModel> listOfCarMechanicUsers = [
  CarMechModel(
      latitude: 33.693735,
      longitude: 73.065151,
      email: 'tariq@gmail.com',
      name: 'Tariq',
      num: '+921505565633'),
  CarMechModel(
      latitude: 33.678552,
      longitude: 73.036156,
      email: 'omer@gmail.com',
      name: 'Omer',
      num: '+921505565634'),
  CarMechModel(
      latitude: 33.689556,
      longitude: 73.055229,
      email: 'kamran@gmail.com',
      name: 'Kamran',
      num: '+921505565635'),
  CarMechModel(
      latitude: 33.704398,
      longitude: 73.037201,
      email: 'shahbaz@gmail.com',
      name: 'Shahbaz',
      num: '+921505565636'),
  CarMechModel(
      latitude: 33.711254,
      longitude: 73.056738,
      email: 'nadeem@gmail.com',
      name: 'Nadeem',
      num: '+921505565637'),
  CarMechModel(
      latitude: 33.715936,
      longitude: 73.077843,
      email: 'faraz@gmail.com',
      name: 'Faraz',
      num: '+921505565638'),
  CarMechModel(
      latitude: 33.731556,
      longitude: 73.098171,
      email: 'waqar@gmail.com',
      name: 'Waqar',
      num: '+921505565639'),
  CarMechModel(
      latitude: 33.746229,
      longitude: 73.065477,
      email: 'azhar@gmail.com',
      name: 'Azhar',
      num: '+921505565640'),
  CarMechModel(
      latitude: 33.761943,
      longitude: 73.083156,
      email: 'junaid@gmail.com',
      name: 'Junaid',
      num: '+921505565641'),
  CarMechModel(
      latitude: 33.777625,
      longitude: 73.055229,
      email: 'sajid@gmail.com',
      name: 'Sajid',
      num: '+921505565642'),
  CarMechModel(
      latitude: 33.586006,
      longitude: 73.057566,
      email: 'asim@gmail.com',
      name: 'Asim',
      num: '+921505565643'),
  CarMechModel(
      latitude: 33.597522,
      longitude: 73.046153,
      email: 'zubair@gmail.com',
      name: 'Zubair',
      num: '+921505565644'),
  CarMechModel(
      latitude: 33.610139,
      longitude: 73.028383,
      email: 'iqbal@gmail.com',
      name: 'Iqbal',
      num: '+921505565645'),
  CarMechModel(
      latitude: 33.623694,
      longitude: 73.054228,
      email: 'faheem@gmail.com',
      name: 'Faheem',
      num: '+921505565646'),
  CarMechModel(
      latitude: 33.636830,
      longitude: 73.060441,
      email: 'kashif@gmail.com',
      name: 'Kashif',
      num: '+921505565647'),
  CarMechModel(
      latitude: 33.648562,
      longitude: 73.048921,
      email: 'zeeshan@gmail.com',
      name: 'Zeeshan',
      num: '+921505565648'),
  CarMechModel(
      latitude: 33.660389,
      longitude: 73.074536,
      email: 'yaseen@gmail.com',
      name: 'Yaseen',
      num: '+921505565649'),
  CarMechModel(
      latitude: 33.672015,
      longitude: 73.092003,
      email: 'noman@gmail.com',
      name: 'Noman',
      num: '+921505565650'),
  CarMechModel(
      latitude: 33.684115,
      longitude: 73.082123,
      email: 'bilal@gmail.com',
      name: 'Bilal',
      num: '+921505565651'),
  CarMechModel(
      latitude: 33.695715,
      longitude: 73.068125,
      email: 'danish@gmail.com',
      name: 'Danish',
      num: '+921505565652'),
];
