import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:ui' as ui;
import 'package:flutter/services.dart';

showToast(String message) {
  Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.red,
      textColor: Colors.white,
      fontSize: 16.0);
}

const textStyle1 = TextStyle(
  fontSize: 30,
  color: Colors.white,
  fontWeight: FontWeight.w500,
  // fontStyle: FontStyle.normal
);

// create a png marker into google map icon marker
// Future<BitmapDescriptor> createMarkerImageFromAsset(String iconPath) async {
//   ImageConfiguration configuration =
//       const ImageConfiguration();
//   var bitmapImage =
//       await BitmapDescriptor.fromAssetImage(configuration, iconPath);
//   return bitmapImage;
// }

Future<BitmapDescriptor> createResizedMarkerImageFromAsset(String assetPath, int width, int height) async {
  final ByteData data = await rootBundle.load(assetPath);
  final ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(), targetWidth: width, targetHeight: height);
  final ui.FrameInfo fi = await codec.getNextFrame();
  final ByteData? byteData = await fi.image.toByteData(format: ui.ImageByteFormat.png);
  final Uint8List resizedMarkerBytes = byteData!.buffer.asUint8List();
  return BitmapDescriptor.fromBytes(resizedMarkerBytes);
}
