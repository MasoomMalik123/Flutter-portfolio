import 'dart:async';
import 'package:carpoling_1/Screens/car_mechanic_panel/mech_main_screen.dart';
import 'package:carpoling_1/Screens/car_tow_panel/cartow_main_screen.dart';
import 'package:carpoling_1/Screens/user_panel/dashboard/dashboard.dart';
import 'package:carpoling_1/bindings/bindings.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'dart:ui';
import '../Assistance/assistant_methods.dart';
import '../Global/global.dart';
import '../Screens/auth/Login_screen.dart';
import '../Screens/driver_panel/driver_main_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  startTimer() {
    Timer(const Duration(seconds: 3), () async {
      if (firebaseAuth.currentUser != null) {
        var docData = await FirebaseFirestore.instance
            .collection('users')
            .doc(firebaseAuth.currentUser!.uid)
            .get();
        var mapData = docData.data() as Map<String, dynamic>;

        // if (currentUser!.emailVerified) {
        if (mapData['role'] == 'User') {
          // Get.offAll(() => const UserMainScreen(), binding: UserBindings());
          Get.offAll(() => const DashboardScreen(), binding: UserBindings());
          await Fluttertoast.showToast(msg: "Successfully Logged In");
        } else if (mapData['role'] == 'Driver') {
          Get.offAll(() => const DriverMainScreen(), binding: DriverBindings());
        } else if (mapData['role'] == 'Car Mechanic') {
          Get.offAll(() => const CarMechMainScreen(),
              binding: MechanicBindings());
          await Fluttertoast.showToast(msg: "Successfully Logged In");
        } else if (mapData['role'] == 'Car Tow') {
          Get.offAll(() => const CarTowMainScreen(), binding: CarTowBindings());
          await Fluttertoast.showToast(msg: "Successfully Logged In");
        }
        // firebaseAuth.currentUser != null
        //     ? AssistantMethods.readCurrentOnlineUserInfo()
        //     : null;
        // Navigator.push(
        //     context, MaterialPageRoute(builder: (c) => const LoginScreen()));
      } else {
        Navigator.push(
            context, MaterialPageRoute(builder: (c) => const LoginScreen()));
      }
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    bool darktheme =
        MediaQuery.of(context).platformBrightness == Brightness.dark;
    return Scaffold(
      body: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Image.asset(darktheme ? 'images/city_dark.jpg' : 'images/city.jpg'),
            const SizedBox(
              height: 120.0,
              width: 120.0,
              // fit: BoxFit.cover,
            ),
          ],
        ),
      ),
    );
  }
}
