import 'package:carpoling_1/Screens/user_panel/car_mechanic/user_car_mech_main_screen.dart';
import 'package:carpoling_1/controller/cartow_controller/cartow_controller.dart';
import 'package:carpoling_1/controller/mechanic_controller/mechanic_controller.dart';
import 'package:carpoling_1/controller/user_controller/car_mechanic_controller/car_mechanic_controller.dart';
import 'package:carpoling_1/controller/user_controller/car_tow_controller/user_car_tow_controller.dart';
import 'package:carpoling_1/controller/driver_controller.dart';
import 'package:carpoling_1/controller/user_controller.dart';
import 'package:carpoling_1/controller/user_profile_controller.dart';
import 'package:get/get.dart';
import 'package:get/get_instance/src/bindings_interface.dart';

class InitialBindings implements Bindings {
  @override
  void dependencies() {
    // Get.put<DriverController>(DriverController());
  }
}

class DriverBindings implements Bindings {
  @override
  void dependencies() {
    Get.put<DriverController>(DriverController());
    Get.put<UserProfileController>(UserProfileController());
    Get.put<UserController>(UserController());
  }
}

class UserBindings implements Bindings {
  @override
  void dependencies() {
    Get.put<UserController>(UserController());
    Get.put<DriverController>(DriverController());
    Get.put<UserProfileController>(UserProfileController());
  }
}

class CustomerCarTowBindings implements Bindings {
  @override
  void dependencies() {
    Get.put<UserCarTowController>(UserCarTowController());
  }
}

class CustomerCarMechanicBindings implements Bindings {
  @override
  void dependencies() {
    Get.put<UserCarMechanicController>(UserCarMechanicController());
  }
}

class MechanicBindings implements Bindings {
  @override
  void dependencies() {
    Get.put<MechanicController>(MechanicController());
    Get.put<UserProfileController>(UserProfileController());

  }
}

class CarTowBindings implements Bindings {
  @override
  void dependencies() {
    Get.put<CarTowController>(CarTowController());
    Get.put<UserProfileController>(UserProfileController());

  }
}

// class CompleteProfileBindings implements Bindings {
//   @override
//   void dependencies() {
//     Get.put<ProfileController>(ProfileController());
//   }
// }
