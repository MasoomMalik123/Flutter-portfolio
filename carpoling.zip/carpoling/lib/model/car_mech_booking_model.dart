import 'package:cloud_firestore/cloud_firestore.dart';

class CarMechanicBookingModel {
  final String carMechanicName;
  final String carMechanicEmail;
  final String carMechanicNum;
  final String customerName;
  final String customerEmail;
  final String customerPhone;
  final String customerAddress;
  final String reasonForBooking;
  final String status;
  final String userId;
  final String carMechanicId;
  final DateTime timeOfRequest;
  final String docId;

  CarMechanicBookingModel({
    required this.carMechanicName,
    required this.carMechanicEmail,
    required this.carMechanicNum,
    required this.customerName,
    required this.customerEmail,
    required this.customerPhone,
    required this.customerAddress,
    required this.reasonForBooking,
    required this.status,
    required this.userId,
    required this.carMechanicId,
    required this.timeOfRequest,
    required this.docId,
  });

  // Factory method to create a CarMechanicBookingModel from a Firestore document
  factory CarMechanicBookingModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

    return CarMechanicBookingModel(
      carMechanicName: data['carMechanicName'] ?? '',
      carMechanicEmail: data['carMechanicEmail'] ?? '',
      carMechanicNum: data['carMechanicNum'] ?? '',
      customerName: data['customerName'] ?? '',
      customerEmail: data['customerEmail'] ?? '',
      customerPhone: data['customerPhone'] ?? '',
      customerAddress: data['customerAddress'] ?? '',
      reasonForBooking: data['reasonForBooking'] ?? '',
      status: data['status'] ?? 'Pending',
      userId: data['userId'] ?? '',
      carMechanicId: data['carMechanicId'] ?? '',
      timeOfRequest: (data['timeOfRequest'] as Timestamp).toDate(),
      docId: data['docId'] ?? '',
    );
  }

  // Method to convert a CarMechanicBookingModel to a Map
  Map<String, dynamic> toMap() {
    return {
      'carMechanicName': carMechanicName,
      'carMechanicEmail': carMechanicEmail,
      'carMechanicNum': carMechanicNum,
      'customerName': customerName,
      'customerEmail': customerEmail,
      'customerPhone': customerPhone,
      'customerAddress': customerAddress,
      'reasonForBooking': reasonForBooking,
      'status': status,
      'userId': userId,
      'carMechanicId': carMechanicId,
      'timeOfRequest': Timestamp.fromDate(timeOfRequest),
      'docId': docId,
    };
  }

  // Method to create a copy of the CarMechanicBookingModel with updated fields
  CarMechanicBookingModel copyWith({
    String? carMechanicName,
    String? carMechanicEmail,
    String? carMechanicNum,
    String? customerName,
    String? customerEmail,
    String? customerPhone,
    String? customerAddress,
    String? reasonForBooking,
    String? status,
    String? userId,
    String? carMechanicId,
    DateTime? timeOfRequest,
    String? docId,
  }) {
    return CarMechanicBookingModel(
      carMechanicName: carMechanicName ?? this.carMechanicName,
      carMechanicEmail: carMechanicEmail ?? this.carMechanicEmail,
      carMechanicNum: carMechanicNum ?? this.carMechanicNum,
      customerName: customerName ?? this.customerName,
      customerEmail: customerEmail ?? this.customerEmail,
      customerPhone: customerPhone ?? this.customerPhone,
      customerAddress: customerAddress ?? this.customerAddress,
      reasonForBooking: reasonForBooking ?? this.reasonForBooking,
      status: status ?? this.status,
      userId: userId ?? this.userId,
      carMechanicId: carMechanicId ?? this.carMechanicId,
      timeOfRequest: timeOfRequest ?? this.timeOfRequest,
      docId: docId ?? this.docId,
    );
  }
}
