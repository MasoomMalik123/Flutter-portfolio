class Ride {
  final String docId;
  final String driverBookedSeats;
  final String driverCarName;
  final String driverEmail;
  final String driverId;
  final String driverName;
  final String driverPhone;
  final String driverRevenue;
  final String driverRideEndLocation;
  final String driverRideStartLocation;
  final String driverSeatsAvailable;
  final String pricePerSeat;
  final String rideStartDate;
  final String rideStartTime;
  final List bookedRides;
  final LatLngs rideStartLatLng;
  final LatLngs rideEndLatLng;

  Ride({
    required this.docId,
    required this.driverBookedSeats,
    required this.driverCarName,
    required this.driverEmail,
    required this.driverId,
    required this.driverName,
    required this.driverPhone,
    required this.driverRevenue,
    required this.driverRideEndLocation,
    required this.driverRideStartLocation,
    required this.driverSeatsAvailable,
    required this.pricePerSeat,
    required this.rideStartDate,
    required this.rideStartTime,
    required this.bookedRides,
    required this.rideEndLatLng,
    required this.rideStartLatLng,
  });

  // Factory method to create a Ride object from a map (from Firebase)
  factory Ride.fromJson(Map<String, dynamic> data) {
    return Ride(
      docId: data['docId'] as String,
      driverBookedSeats: data['driverBookedSeats'] as String,
      driverCarName: data['driverCarName'] as String,
      driverEmail: data['driverEmail'] as String,
      driverId: data['driverId'] as String,
      driverName: data['driverName'] as String,
      driverPhone: data['driverPhone'] as String,
      driverRevenue: data['driverRevenue'] as String? ?? '0',
      driverRideEndLocation: data['driverRideEndLocation'] as String,
      driverRideStartLocation: data['driverRideStartLocation'] as String,
      driverSeatsAvailable: data['driverSeatsAvailable'] as String,
      pricePerSeat: data['pricePerSeat'] as String,
      rideStartDate: data['rideStartDate'] as String,
      rideStartTime: data['rideStartTime'] as String,
      bookedRides: data['bookedRides'] ?? [],
      rideStartLatLng:
          LatLngs.fromJson(data['rideStartLatLng'] ?? {}), // updated to LatLngs
      rideEndLatLng: LatLngs.fromJson(data['rideEndLatLng'] ?? {}),
    );
  }

  // Method to convert a Ride object to a map (for Firebase)
  Map<String, dynamic> toJson() {
    return {
      'docId': docId,
      'driverBookedSeats': driverBookedSeats,
      'driverCarName': driverCarName,
      'driverEmail': driverEmail,
      'driverId': driverId,
      'driverName': driverName,
      'driverPhone': driverPhone,
      'driverRevenue': driverRevenue,
      'driverRideEndLocation': driverRideEndLocation,
      'driverRideStartLocation': driverRideStartLocation,
      'driverSeatsAvailable': driverSeatsAvailable,
      'pricePerSeat': pricePerSeat,
      'rideStartDate': rideStartDate,
      'rideStartTime': rideStartTime,
      'bookedRides': bookedRides,
      'rideStartLatLng': {
        'latitude': rideStartLatLng.latitude,
        'longitude': rideStartLatLng.longitude,
      }, // new field
      'rideEndLatLng': {
        'latitude': rideEndLatLng.latitude,
        'longitude': rideEndLatLng.longitude,
      },
    };
  }
}

class LatLngs {
  final String latitude;
  final String longitude;

  LatLngs(this.latitude, this.longitude);

  // Factory method to create a LatLngs object from a map
  factory LatLngs.fromJson(Map<String, dynamic> data) {
    return LatLngs(
      data['latitude'] ?? "0",
      data['longitude'] ?? "0",
    );
  }

  // Method to convert a LatLngs object to a map
  Map<String, dynamic> toJson() {
    return {
      'latitude': latitude,
      'longitude': longitude,
    };
  }
}
