class CarMechModel {
  final double latitude;
  final double longitude;
  final String name;
  final String num;
  final String email;

  CarMechModel({
    required this.latitude,
    required this.longitude,
    required this.email,
    required this.name,
    required this.num,
  });

  // Factory constructor to create a CarMechModel from a map (e.g., Firestore document)
  factory CarMechModel.fromJson(Map<String, dynamic> json) {
    return CarMechModel(
      latitude: json['lat'],
      longitude: json['long'],
      email: json['email'],
      name: json['name'],
      num: json['num'],
    );
  }

  // Method to convert CarMechModel to a map
  Map<String, dynamic> toJson() {
    return {
      'lat': latitude,
      'long': longitude,
      'email': email,
      'name': name,
      'num': num,
    };
  }
}
