import 'package:cloud_firestore/cloud_firestore.dart';

class CarTowBookingModel {
  final String carTowName;
  final String carTowEmail;
  final String carTowNum;
  final String customerName;
  final String customerEmail;
  final String customerPhone;
  final String customerAddress;
  final String reasonForBooking;
  final String status;
  final String userId;
  final String carTowId;
  final DateTime timeOfRequest;
  final String docId;

  CarTowBookingModel({
    required this.carTowName,
    required this.carTowEmail,
    required this.carTowNum,
    required this.customerName,
    required this.customerEmail,
    required this.customerPhone,
    required this.customerAddress,
    required this.reasonForBooking,
    required this.status,
    required this.userId,
    required this.carTowId,
    required this.timeOfRequest,
    required this.docId,
  });

  // Factory method to create a CarTowBookingModel from a Firestore document
  factory CarTowBookingModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

    return CarTowBookingModel(
      carTowName: data['carTowName'] ?? '',
      carTowEmail: data['carTowEmail'] ?? '',
      carTowNum: data['carTowNum'] ?? '',
      customerName: data['customerName'] ?? '',
      customerEmail: data['customerEmail'] ?? '',
      customerPhone: data['customerPhone'] ?? '',
      customerAddress: data['customerAddress'] ?? '',
      reasonForBooking: data['reasonForBooking'] ?? '',
      status: data['status'] ?? 'Pending',
      userId: data['userId'] ?? '',
      carTowId: data['carTowId'] ?? '',
      timeOfRequest: (data['timeOfRequest'] as Timestamp).toDate(),
      docId: data['docId'] ?? '',
    );
  }

  // Method to convert a CarTowBookingModel to a Map
  Map<String, dynamic> toMap() {
    return {
      'carTowName': carTowName,
      'carTowEmail': carTowEmail,
      'carTowNum': carTowNum,
      'customerName': customerName,
      'customerEmail': customerEmail,
      'customerPhone': customerPhone,
      'customerAddress': customerAddress,
      'reasonForBooking': reasonForBooking,
      'status': status,
      'userId': userId,
      'carTowId': carTowId,
      'timeOfRequest': Timestamp.fromDate(timeOfRequest),
      'docId': docId,
    };
  }

  // Method to create a copy of the CarTowBookingModel with updated fields
  CarTowBookingModel copyWith({
    String? carTowName,
    String? carTowEmail,
    String? carTowNum,
    String? customerName,
    String? customerEmail,
    String? customerPhone,
    String? customerAddress,
    String? reasonForBooking,
    String? status,
    String? userId,
    String? carTowId,
    DateTime? timeOfRequest,
    String? docId,
  }) {
    return CarTowBookingModel(
      carTowName: carTowName ?? this.carTowName,
      carTowEmail: carTowEmail ?? this.carTowEmail,
      carTowNum: carTowNum ?? this.carTowNum,
      customerName: customerName ?? this.customerName,
      customerEmail: customerEmail ?? this.customerEmail,
      customerPhone: customerPhone ?? this.customerPhone,
      customerAddress: customerAddress ?? this.customerAddress,
      reasonForBooking: reasonForBooking ?? this.reasonForBooking,
      status: status ?? this.status,
      userId: userId ?? this.userId,
      carTowId: carTowId ?? this.carTowId,
      timeOfRequest: timeOfRequest ?? this.timeOfRequest,
      docId: docId ?? this.docId,
    );
  }
}
