class CarTowModel {
  final double latitude;
  final double longitude;
  final String name;
  final String num;
  final String email;

  CarTowModel({
    required this.latitude,
    required this.longitude,
    required this.email,
    required this.name,
    required this.num,
  });

  // Factory constructor to create a CarTowModel from a map (e.g., Firestore document)
  factory CarTowModel.fromJson(Map<String, dynamic> json) {
    return CarTowModel(
      latitude: json['lat'],
      longitude: json['long'],
      email: json['email'],
      name: json['name'],
      num: json['num'],
    );
  }

  // Method to convert CarTowModel to a map
  Map<String, dynamic> toJson() {
    return {
      'lat': latitude,
      'long': longitude,
      'email': email,
      'name': name,
      'num': num,
    };
  }
}
